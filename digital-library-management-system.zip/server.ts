import express from "express";
import path from "path";
import crypto from "crypto";
import { createServer as createViteServer } from "vite";
import { LibraryDatabase, User } from "./src/server/db.ts";

const app = express();
const PORT = 3000;

// Body parsing middlewares
app.use(express.json());

// In-memory Session Manager
const activeSessions = new Map<string, { user: User; expiresAt: number }>();

// Simple session token generator
function generateSessionToken(): string {
  return "session_" + crypto.randomBytes(24).toString("hex");
}

// Session validation middleware
function authenticate(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Session validation expired. Please sign in again." });
  }

  const token = authHeader.split(" ")[1];
  const session = activeSessions.get(token);

  if (!session) {
    return res.status(401).json({ error: "Your library session is invalid or has expired." });
  }

  if (Date.now() > session.expiresAt) {
    activeSessions.delete(token);
    return res.status(401).json({ error: "Your session has expired. Please sign in again." });
  }

  // Extend session duration on active navigation/api requests
  session.expiresAt = Date.now() + 3 * 60 * 60 * 1000; // 3 hours
  
  // Attach current user to request
  (req as any).user = session.user;
  (req as any).token = token;
  next();
}

// Admin privileges guard
function requireAdmin(req: express.Request, res: express.Response, next: express.NextFunction) {
  const user = (req as any).user as User;
  if (!user || user.role !== "admin") {
    return res.status(403).json({ error: "Access denied. Admin credentials required." });
  }
  next();
}

async function startServer() {
  // Ensure DB initializes correctly
  await LibraryDatabase.init();

  // --- API Endpoints ---
  
  // 1. Health check or state validation
  app.get("/api/health", (req, res) => {
    res.json({
      status: "online",
      time: new Date().toISOString(),
      service: "Digital Library Management Engine"
    });
  });

  // 2. User Registration
  app.post("/api/auth/register", async (req, res) => {
    const { name, email, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: "Name, email address, and a secure password are required." });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: "Password must be at least 6 characters in length." });
    }

    try {
      const user = await LibraryDatabase.createUser(name, email, password, "user");
      const token = generateSessionToken();
      
      activeSessions.set(token, {
        user,
        expiresAt: Date.now() + 3 * 60 * 60 * 1000 // 3 hours
      });

      res.status(201).json({
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role
        }
      });
    } catch (e: any) {
      res.status(400).json({ error: e.message || "An error occurred during account creation." });
    }
  });

  // 3. User Login
  app.post("/api/auth/login", async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: "Email address and password parameters are required." });
    }

    try {
      const user = await LibraryDatabase.authenticateUser(email, password);
      const token = generateSessionToken();
      
      activeSessions.set(token, {
        user,
        expiresAt: Date.now() + 3 * 60 * 60 * 1000
      });

      res.status(200).json({
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role
        }
      });
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Authentication failed." });
    }
  });

  // 4. Retrieve Active Session User Profile
  app.get("/api/auth/me", authenticate, (req, res) => {
    const user = (req as any).user as User;
    res.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        createdAt: user.createdAt
      }
    });
  });

  // 5. Update Candidate Profile Details
  app.post("/api/profile/update", authenticate, async (req, res) => {
    const user = (req as any).user as User;
    const { name, email } = req.body;

    if (!name || !email) {
      return res.status(400).json({ error: "Updated name and email address cannot be empty." });
    }

    try {
      const updatedUser = await LibraryDatabase.updateProfile(user.id, name, email);
      
      // Update our stored session instance as well
      const token = (req as any).token;
      const currentSession = activeSessions.get(token);
      if (currentSession) {
        currentSession.user = updatedUser;
      }

      res.json({
        user: {
          id: updatedUser.id,
          name: updatedUser.name,
          email: updatedUser.email
        }
      });
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Failed to update profile specifications." });
    }
  });

  // 6. Security Password Update
  app.post("/api/profile/password", authenticate, async (req, res) => {
    const user = (req as any).user as User;
    const { currentPassword, newPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: "Current verifying password and new secure password are required." });
    }
    if (newPassword.length < 6) {
      return res.status(400).json({ error: "New password must contain at least 6 characters." });
    }

    try {
      await LibraryDatabase.changePassword(user.id, currentPassword, newPassword);
      res.json({ status: "success", message: "Password updated successfully." });
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Failed to verify or change password." });
    }
  });

  // 7. Get Books listing
  app.get("/api/books", authenticate, async (req, res) => {
    try {
      const books = await LibraryDatabase.getBooks();
      res.json(books);
    } catch (e) {
      res.status(500).json({ error: "Failed to load bookkeeping directory." });
    }
  });

  // 8. Create a book (Admin only)
  app.post("/api/books", authenticate, requireAdmin, async (req, res) => {
    const { title, author, category, isbn, totalCopies, location, finePerDay, synopsis, publishedYear } = req.body;
    if (!title || !author || !category || !isbn || !totalCopies || !location) {
      return res.status(400).json({ error: "Essential book catalog fields are missing." });
    }

    try {
      const newBook = await LibraryDatabase.createBook({
        title,
        author,
        category,
        isbn,
        totalCopies: Math.max(1, Number(totalCopies)),
        location,
        finePerDay: Number(finePerDay) || 0.50,
        synopsis: synopsis || "",
        publishedYear: Number(publishedYear) || new Date().getFullYear()
      });
      res.status(201).json(newBook);
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Could not publish book record." });
    }
  });

  // 9. Update a book (Admin only)
  app.put("/api/books/:id", authenticate, requireAdmin, async (req, res) => {
    const bookId = req.params.id;
    try {
      const updatedBook = await LibraryDatabase.updateBook(bookId, req.body);
      res.json(updatedBook);
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Failed to modify book details." });
    }
  });

  // 10. Delete a book (Admin only)
  app.delete("/api/books/:id", authenticate, requireAdmin, async (req, res) => {
    const bookId = req.params.id;
    try {
      await LibraryDatabase.deleteBook(bookId);
      res.json({ status: "success", message: "Book record successfully purged." });
    } catch (e: any) {
      res.status(450).json({ error: e.message || "Could not delete this catalog series." });
    }
  });

  // 11. Retrieve members (Admin only)
  app.get("/api/members", authenticate, requireAdmin, async (req, res) => {
    try {
      const members = await LibraryDatabase.getAllMembers();
      res.json(members);
    } catch (e) {
      res.status(500).json({ error: "Failed to download database membership roster." });
    }
  });

  // 12. Delete active member roster (Admin only)
  app.delete("/api/members/:id", authenticate, requireAdmin, async (req, res) => {
    try {
      await LibraryDatabase.deleteMember(req.params.id);
      res.json({ status: "success", message: "Member account deleted from rosters." });
    } catch (e) {
      res.status(500).json({ error: "Failed to update membership indices." });
    }
  });

  // 13. Circulation Logs (GET)
  app.get("/api/transactions", authenticate, async (req, res) => {
    const user = (req as any).user as User;
    try {
      // Users only see their logs. Admin sees all!
      if (user.role === "admin") {
        const logs = await LibraryDatabase.getTransactions();
        res.json(logs);
      } else {
        const logs = await LibraryDatabase.getTransactions(user.id);
        res.json(logs);
      }
    } catch (e) {
      res.status(500).json({ error: "Failed to download circulation audits." });
    }
  });

  // 14. Issue Book Trigger
  app.post("/api/transactions/issue", authenticate, async (req, res) => {
    const user = (req as any).user as User;
    const { bookId } = req.body;
    if (!bookId) {
      return res.status(400).json({ error: "Reference book parameter is missing." });
    }

    try {
      const tx = await LibraryDatabase.issueBook(user.id, user.name, bookId);
      res.status(201).json(tx);
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Failed to process lending approval." });
    }
  });

  // 15. Return Book Trigger
  app.post("/api/transactions/return/:id", authenticate, async (req, res) => {
    const txId = req.params.id;
    try {
      const tx = await LibraryDatabase.returnBook(txId);
      res.json(tx);
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Return validation failed." });
    }
  });

  // 16. Advance Reserving system
  app.post("/api/transactions/reserve", authenticate, async (req, res) => {
    const user = (req as any).user as User;
    const { bookId } = req.body;
    if (!bookId) {
      return res.status(400).json({ error: "Reference book identifier is missing." });
    }

    try {
      const tx = await LibraryDatabase.reserveBook(user.id, user.name, bookId);
      res.status(201).json(tx);
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Advance booking request failed." });
    }
  });

  // 17. Conclude fine settlement
  app.post("/api/transactions/pay-fine/:id", authenticate, async (req, res) => {
    const txId = req.params.id;
    try {
      const tx = await LibraryDatabase.payFine(txId);
      res.json(tx);
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Fine pay calculation failed." });
    }
  });

  // 18. Cancel reservation session
  app.post("/api/transactions/cancel-reservation/:id", authenticate, async (req, res) => {
    const txId = req.params.id;
    try {
      await LibraryDatabase.cancelReservation(txId);
      res.json({ status: "success", message: "Reservation cancelled." });
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Reservation abort cancelled." });
    }
  });

  // 19. Send feedback query (Simulate real email communication)
  app.post("/api/queries", authenticate, async (req, res) => {
    const user = (req as any).user as User;
    const { subject, message } = req.body;
    if (!subject || !message) {
      return res.status(400).json({ error: "Email subject and core query message are required." });
    }

    try {
      const query = await LibraryDatabase.submitQuery(user.name, user.email, subject, message);
      res.status(201).json(query);
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Could not route email query." });
    }
  });

  // 20. List enquiries
  app.get("/api/queries", authenticate, async (req, res) => {
    const user = (req as any).user as User;
    try {
      const all = await LibraryDatabase.getQueries();
      if (user.role === "admin") {
        res.json(all);
      } else {
        // filter individual member enquiries
        res.json(all.filter(q => q.email.toLowerCase() === user.email.toLowerCase()));
      }
    } catch (e) {
      res.status(500).json({ error: "Queries download failed." });
    }
  });

  // 21. Respond to enquirers (Admin only)
  app.post("/api/queries/respond/:id", authenticate, requireAdmin, async (req, res) => {
    const qId = req.params.id;
    const { response } = req.body;
    if (!response) {
      return res.status(400).json({ error: "A reply/response body is required to mail enquirers." });
    }

    try {
      const updated = await LibraryDatabase.respondToQuery(qId, response);
      res.json(updated);
    } catch (e: any) {
      res.status(400).json({ error: e.message || "Failed to catalog message transmission." });
    }
  });

  // 22. Delete queries indicators
  app.delete("/api/queries/:id", authenticate, requireAdmin, async (req, res) => {
    try {
      await LibraryDatabase.deleteQuery(req.params.id);
      res.json({ status: "success", message: "Query record removed from archives." });
    } catch (e) {
      res.status(500).json({ error: "Failed to purge database indicators." });
    }
  });

  // 23. Reports & Audits Metrics (Admin only)
  app.get("/api/stats", authenticate, requireAdmin, async (req, res) => {
    try {
      const stats = await LibraryDatabase.getDashboardStats();
      res.json(stats);
    } catch (e) {
      res.status(500).json({ error: "Could not compile statistical audits." });
    }
  });

  // 24. End session and Sign out
  app.post("/api/auth/logout", authenticate, (req, res) => {
    const token = (req as any).token;
    activeSessions.delete(token);
    res.json({ status: "success", message: "Logged out successfully from session database." });
  });

  // --- Vite Dev Middleware and Static Asset Distribution ---

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Library Automation Engine] Operational on host bind port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Critical: Library Server Boot Failure:", err);
});

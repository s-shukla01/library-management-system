import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Laptop, Mail, Lock, User, KeyRound, Sparkles, HelpCircle, ChevronRight, BookOpen, AlertCircle } from "lucide-react";

interface LoginScreenProps {
  onLoginSuccess: (token: string, user: { id: string; name: string; email: string; role: "admin" | "user" }) => void;
}

export default function LoginScreen({ onLoginSuccess }: LoginScreenProps) {
  const [activePortal, setActivePortal] = useState<"landing" | "login">("landing");
  const [isRegister, setIsRegister] = useState(false);
  const [targetRole, setTargetRole] = useState<"admin" | "user">("user");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg(null);

    const url = isRegister ? "/api/auth/register" : "/api/auth/login";
    const payload = isRegister ? { name, email, password } : { email, password };

    try {
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || "An error occurred during verification.");
      }

      onLoginSuccess(data.token, data.user);
    } catch (err: any) {
      setErrorMsg(err.message || "Credential validation failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const autofillDemo = (role: "admin" | "user") => {
    if (role === "admin") {
      setEmail("admin@example.com");
      setPassword("admin123");
    } else {
      setEmail("student@example.com");
      setPassword("123456");
    }
    setTargetRole(role);
    setIsRegister(false);
    setActivePortal("login");
    setErrorMsg(null);
  };

  return (
    <div id="login_container" className="min-h-screen grid grid-cols-1 md:grid-cols-12 overflow-hidden bg-[#fafafa] font-sans antialiased text-slate-800">
      
      {/* LEFT COLUMN: THE REAL TASK 5 PRESENTATION SLIDE LAYOUT */}
      <div id="slide_left_panel" className="md:col-span-5 bg-[#e2e2e2] p-8 md:p-16 flex flex-col justify-between relative border-r border-[#d4d4d4]">
        <div>
          <motion.h1 
            initial={{ opacity: 0, x: -10 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
            className="text-6xl md:text-7xl font-sans font-extrabold tracking-tight text-[#2d3748]"
          >
            TASK 5
          </motion.h1>
        </div>

        <div className="my-auto py-12 flex justify-start items-center">
          {/* Exact Replica Laptop Outline Emblem */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.1, duration: 0.5 }}
            className="text-slate-800"
          >
            <svg 
              className="w-40 h-40" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor" 
              strokeWidth="1.2" 
              strokeLinecap="round" 
              strokeLinejoin="round"
            >
              <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
              <line x1="1" y1="20" x2="23" y2="20" />
              <line x1="5" y1="20" x2="19" y2="20" strokeWidth="2" />
              <rect x="4" y="5" width="6" height="4" rx="0.5" />
              <line x1="12" y1="5" x2="20" y2="5" />
              <line x1="12" y1="7" x2="18" y2="7" />
              <line x1="12" y1="9" x2="16" y2="9" />
            </svg>
          </motion.div>
        </div>

        <div className="text-xs font-mono text-[#718096] mt-auto pt-6 border-t border-[#cbd5e0]">
          Java Development Core Program Match • Automated Solutions
        </div>
      </div>

      {/* RIGHT COLUMN: INTERACTIVE SLIDE DECK / PORTAL FLOWS */}
      <div id="slide_right_panel" className="md:col-span-7 bg-[#1e252b] p-8 md:p-14 lg:p-16 flex flex-col justify-center text-slate-200">
        <AnimatePresence mode="wait">
          {activePortal === "landing" ? (
            <motion.div 
              key="landing_view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="space-y-6 max-w-2xl"
            >
              <div>
                <span className="text-[#fab005] font-sans font-bold tracking-widest text-lg md:text-xl uppercase block">
                  DIGITAL LIBRARY MANAGEMENT
                </span>
                <div className="h-0.5 bg-[#fab005]/40 w-16 mt-2 rounded"></div>
              </div>

              {/* Exact Presentation Slide Descriptions */}
              <div className="space-y-5 text-sm md:text-base text-slate-300 leading-relaxed font-sans">
                <p>
                  • The main objective of this project is to provide a complete automated Library by digitizing its each and every functionality. Starting from the book-keeping, issuing of books, fine generation, advance booking and report generation all will be accomplished under one single project. The project will be a web based project with a database server responsible for maintaining every single detail of the Library. It has a very user friendly interface which can easily be operated by any non-technical person.
                </p>
                
                <p className="font-semibold text-slate-100 italic pt-1">
                  There are essentially two modules of this software;
                </p>

                <ul className="space-y-3.5 pl-2">
                  <li className="flex items-start gap-2.5">
                    <span className="text-[#fab005] mt-1 shrink-0 font-bold">•</span>
                    <span>
                      <strong className="text-white font-semibold">Admin module:</strong> Admin will have complete control over the system. Admin has permissions to update, delete or modify any existing record or make a new entry (books and members).
                    </span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="text-[#fab005] mt-1 shrink-0 font-bold">•</span>
                    <span>
                      <strong className="text-white font-semibold">Users:</strong> The normal users enjoy only limited privileges. They have a view access to the books. They can browse through the categories, search for a particular book, return and issue a book. They are also provided with an email option in case of a query.
                    </span>
                  </li>
                </ul>
              </div>

              {/* Interactive Multi-Portal Launch Actions */}
              <div className="pt-6 border-t border-slate-700/50 space-y-4">
                <h4 className="text-xs font-mono uppercase tracking-widest text-[#fab005] font-bold">Interactive Portal Control</h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <button 
                    onClick={() => {
                      setIsRegister(false);
                      setTargetRole("user");
                      setActivePortal("login");
                    }}
                    className="p-4 bg-slate-800/80 hover:bg-slate-700/85 border border-slate-700 rounded-xl flex items-center justify-between text-left transition-all group shrink-0 cursor-pointer"
                  >
                    <div>
                      <span className="block font-bold text-slate-100 group-hover:text-[#fab005] transition-colors">Normal Student Portal</span>
                      <span className="text-xs text-slate-400 mt-0.5 block">Search books, issue items, query librarian</span>
                    </div>
                    <ChevronRight className="h-5 w-5 text-slate-500 group-hover:text-[#fab005] transition-transform group-hover:translate-x-1" />
                  </button>

                  <button 
                    onClick={() => {
                      setIsRegister(false);
                      setTargetRole("admin");
                      setActivePortal("login");
                    }}
                    className="p-4 bg-slate-800/80 hover:bg-slate-700/85 border border-slate-700 rounded-xl flex items-center justify-between text-left transition-all group shrink-0 cursor-pointer"
                  >
                    <div>
                      <span className="block font-bold text-slate-100 group-hover:text-[#fab005] transition-colors">Librarian Admin Portal</span>
                      <span className="text-xs text-slate-400 mt-0.5 block">Bookkeeping, fine audits, reply enquiries</span>
                    </div>
                    <ChevronRight className="h-5 w-5 text-slate-500 group-hover:text-[#fab005] transition-transform group-hover:translate-x-1" />
                  </button>
                </div>

                {/* Instant Demo Accounts Shortcut */}
                <div className="p-3.5 bg-slate-800/40 border border-slate-700/40 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-2 text-slate-300">
                    <Sparkles className="h-4 w-4 text-[#fab005]" />
                    <span>Quick Autofill Demo Accounts:</span>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => autofillDemo("user")}
                      className="px-3 py-1.5 bg-slate-700/70 hover:bg-slate-600 rounded-lg text-slate-200 hover:text-white font-medium cursor-pointer transition-colors"
                    >
                      Alex Devishankar (User)
                    </button>
                    <button 
                      onClick={() => autofillDemo("admin")}
                      className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 rounded-lg text-slate-950 font-bold cursor-pointer transition-colors"
                    >
                      Chief Librarian (Admin)
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="login_view"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="max-w-md w-full mx-auto space-y-6"
            >
              {/* Back to specifications menu */}
              <button 
                onClick={() => {
                  setActivePortal("landing");
                  setErrorMsg(null);
                }}
                className="text-xs text-[#fab005] hover:underline flex items-center gap-1 cursor-pointer focus:outline-none mb-4"
              >
                ← Back to Slide Spec Documents
              </button>

              <div>
                <span className="text-[#fab005] font-mono text-xs tracking-widest uppercase font-bold block">
                  {targetRole === "admin" ? "STAFF SECURE PORTAL" : "ACADEMIC CIRCULATION"}
                </span>
                <h3 className="text-2xl md:text-3xl font-extrabold tracking-tight text-white mt-1">
                  {isRegister ? "Registration Center" : `Sign In • ${targetRole === "admin" ? "Library Admin" : "Student Member"}`}
                </h3>
                <p className="text-slate-400 text-sm mt-1.5">
                  {isRegister 
                    ? "Establish digital archives membership credentials below." 
                    : "Supply local login details to access automated catalogs."}
                </p>
              </div>

              {/* Notice indicator to help non-technical users */}
              <div className="p-3 bg-slate-800/65 border border-slate-700/60 rounded-xl flex items-start gap-2.5 text-xs text-slate-300">
                <AlertCircle className="h-4.5 w-4.5 text-[#fab005] shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold text-white">Default test log-in:</span> Use the bypass credentials:
                  <div className="mt-1 flex gap-1 font-mono text-[11px] text-[#fab005]">
                    <span>{targetRole === "admin" ? "admin@example.com" : "student@example.com"}</span>
                    <span className="text-slate-500">|</span>
                    <span>{targetRole === "admin" ? "admin123" : "123456"}</span>
                  </div>
                </div>
              </div>

              {errorMsg && (
                <div className="p-3.5 bg-red-950/40 border border-red-800/60 rounded-xl text-xs text-red-300">
                  {errorMsg}
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                {isRegister && (
                  <div>
                    <label className="block text-xs font-mono tracking-wider uppercase text-slate-400 font-bold mb-1">Full Member Name</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                        <User className="h-4 w-4" />
                      </span>
                      <input 
                        type="text" 
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="E.g., Alex Devishankar"
                        className="w-full bg-[#181d22] border border-slate-700/60 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all font-sans"
                      />
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-mono tracking-wider uppercase text-slate-400 font-bold mb-1">Email Address</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                      <Mail className="h-4 w-4" />
                    </span>
                    <input 
                      type="email" 
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="student@example.com"
                      className="w-full bg-[#181d22] border border-slate-700/60 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono tracking-wider uppercase text-slate-400 font-bold mb-1">Passphrase Code</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-500">
                      <Lock className="h-4 w-4" />
                    </span>
                    <input 
                      type="password" 
                      required
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="••••••"
                      className="w-full bg-[#181d22] border border-slate-700/60 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 focus:ring-1 focus:ring-amber-500 transition-all font-mono"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-[#fab005] hover:bg-amber-400 text-slate-950 py-2.5 px-4 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-amber-500/10 disabled:opacity-50"
                >
                  {loading ? (
                    <span className="inline-block h-4 w-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span>
                  ) : (
                    <>
                      {isRegister ? "Submit Library Enrollment" : `Unlock ${targetRole === "admin" ? "Management Vault" : "Circulation Desk"}`}
                      <KeyRound className="h-4 w-4" />
                    </>
                  )}
                </button>
              </form>

              <div className="text-center pt-3 border-t border-slate-800 flex justify-between items-center text-xs text-slate-400">
                <button 
                  type="button" 
                  onClick={() => {
                    setIsRegister(!isRegister);
                    setErrorMsg(null);
                  }}
                  className="hover:text-white underline transition-colors"
                >
                  {isRegister ? "Have credentials? Sign in instead" : "New member? Sign up for free"}
                </button>
                
                <button 
                  type="button" 
                  onClick={() => {
                    setTargetRole(targetRole === "admin" ? "user" : "admin");
                    setErrorMsg(null);
                  }}
                  className="hover:text-white transition-colors text-[#fab005]"
                >
                  Switch to {targetRole === "admin" ? "Student" : "Librarian"} Portal
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Book, Search, Info, Plus, Trash2, Check, X, LogOut, Mail, Lock, User, 
  Sparkles, Send, CircleDollarSign, Calendar, Clock, BarChart2, Users, 
  FileText, Settings, ShieldAlert, CheckCircle, MapPin, Tag, BookOpen,
  Filter, AlertTriangle, RefreshCw, ChevronRight, Bookmark, Landmark, ShieldCheck,
  Edit2
} from "lucide-react";
import LoginScreen from "./components/LoginScreen";
import { 
  User as UserType, Book as BookType, Transaction, ContactQuery, DashboardStats 
} from "./types";

export default function App() {
  // Session authentication state variables
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("library_token"));
  const [user, setUser] = useState<UserType | null>(null);
  const [loadingAuth, setLoadingAuth] = useState(false);

  // Core navigation tabs
  // Students: "catalog" | "my_loans" | "my_reservations" | "contact" | "profile"
  // Admins: "catalog" | "circulation" | "members" | "enquiries" | "reports" | "profile"
  const [activeTab, setActiveTab] = useState<string>("catalog");

  // Catalog repository variables
  const [books, setBooks] = useState<BookType[]>([]);
  const [loadingBooks, setLoadingBooks] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");

  // Member lists for staff audits
  const [members, setMembers] = useState<UserType[]>([]);
  const [loadingMembers, setLoadingMembers] = useState(false);

  // Circulation loan history
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loadingTransactions, setLoadingTransactions] = useState(false);

  // Query communication variables
  const [queries, setQueries] = useState<ContactQuery[]>([]);
  const [loadingQueries, setLoadingQueries] = useState(false);
  const [querySubject, setQuerySubject] = useState("");
  const [queryMessage, setQueryMessage] = useState("");
  const [submitQueryFeedback, setSubmitQueryFeedback] = useState<string | null>(null);

  // Admin query responding form
  const [respondingQueryId, setRespondingQueryId] = useState<string | null>(null);
  const [adminResponseText, setAdminResponseText] = useState("");

  // Report statistics variables
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(false);

  // CRUD operation variables for catalog modifications
  const [editingBookId, setEditingBookId] = useState<string | null>(null);
  const [isAddingBook, setIsAddingBook] = useState(false);
  const [crudError, setCrudError] = useState<string | null>(null);

  // New book state matching database schemas
  const [bookTitle, setBookTitle] = useState("");
  const [bookAuthor, setBookAuthor] = useState("");
  const [bookCategory, setBookCategory] = useState("Java Development");
  const [bookIsbn, setBookIsbn] = useState("");
  const [bookCopies, setBookCopies] = useState(3);
  const [bookLocation, setBookLocation] = useState("");
  const [bookSynopsis, setBookSynopsis] = useState("");
  const [bookYear, setBookYear] = useState(2024);
  const [bookFineRate, setBookFineRate] = useState(0.50);

  // Personal user configuration profile variables
  const [profileName, setProfileName] = useState("");
  const [profileEmail, setProfileEmail] = useState("");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [profileFeedback, setProfileFeedback] = useState<{ type: "success" | "error"; msg: string } | null>(null);
  const [passwordFeedback, setPasswordFeedback] = useState<{ type: "success" | "error"; msg: string } | null>(null);
  const [submittingProfile, setSubmittingProfile] = useState(false);
  const [submittingPassword, setSubmittingPassword] = useState(false);

  // Trigger load indicator on action updates
  const [actionLoadingId, setActionLoadingId] = useState<string | null>(null);

  // Load and refresh indices on mount/session changes
  useEffect(() => {
    if (token) {
      setLoadingAuth(true);
      fetch("/api/auth/me", {
        headers: { "Authorization": `Bearer ${token}` }
      })
      .then(res => {
        if (!res.ok) throw new Error("Verification failed");
        return res.json();
      })
      .then(data => {
        setUser(data.user);
        setProfileName(data.user.name);
        setProfileEmail(data.user.email);
        
        // Populate core directories
        fetchBooks(token);
        fetchTransactions(token);
        fetchQueries(token);

        if (data.user.role === "admin") {
          fetchMembers(token);
          fetchStats(token);
          setActiveTab("reports"); // Start Admin on metrics
        } else {
          setActiveTab("catalog"); // Start Student on book browser
        }
      })
      .catch(() => {
        handleLogoutClean();
      })
      .finally(() => {
        setLoadingAuth(false);
      });
    }
  }, [token]);

  // Auth Operations
  const handleLoginSuccess = (newToken: string, loginUser: any) => {
    localStorage.setItem("library_token", newToken);
    setToken(newToken);
    setUser(loginUser);
    setProfileName(loginUser.name);
    setProfileEmail(loginUser.email);
    
    // Download arrays
    fetchBooks(newToken);
    fetchTransactions(newToken);
    fetchQueries(newToken);

    if (loginUser.role === "admin") {
      fetchMembers(newToken);
      fetchStats(newToken);
      setActiveTab("reports");
    } else {
      setActiveTab("catalog");
    }
  };

  const handleLogoutClean = () => {
    if (token) {
      fetch("/api/auth/logout", {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` }
      }).catch(() => {});
    }
    localStorage.removeItem("library_token");
    setToken(null);
    setUser(null);
    setActiveTab("catalog");
    setBooks([]);
    setTransactions([]);
    setMembers([]);
    setQueries([]);
    setStats(null);
  };

  // --- REST Fetch Handlers ---
  
  const fetchBooks = (jwtToken: string) => {
    setLoadingBooks(true);
    fetch("/api/books", {
      headers: { "Authorization": `Bearer ${jwtToken}` }
    })
    .then(res => res.json())
    .then(data => {
      if (Array.isArray(data)) setBooks(data);
    })
    .catch(err => console.error("Book loading failure:", err))
    .finally(() => setLoadingBooks(false));
  };

  const fetchMembers = (jwtToken: string) => {
    setLoadingMembers(true);
    fetch("/api/members", {
      headers: { "Authorization": `Bearer ${jwtToken}` }
    })
    .then(res => res.json())
    .then(data => {
      if (Array.isArray(data)) setMembers(data);
    })
    .catch(err => console.error("Roster loading failure:", err))
    .finally(() => setLoadingMembers(false));
  };

  const fetchTransactions = (jwtToken: string) => {
    setLoadingTransactions(true);
    fetch("/api/transactions", {
      headers: { "Authorization": `Bearer ${jwtToken}` }
    })
    .then(res => res.json())
    .then(data => {
      if (Array.isArray(data)) setTransactions(data);
    })
    .catch(err => console.error("Circulation load failure:", err))
    .finally(() => setLoadingTransactions(false));
  };

  const fetchQueries = (jwtToken: string) => {
    setLoadingQueries(true);
    fetch("/api/queries", {
      headers: { "Authorization": `Bearer ${jwtToken}` }
    })
    .then(res => res.json())
    .then(data => {
      if (Array.isArray(data)) setQueries(data);
    })
    .catch(err => console.error("Queries load failure:", err))
    .finally(() => setLoadingQueries(false));
  };

  const fetchStats = (jwtToken: string) => {
    setLoadingStats(true);
    fetch("/api/stats", {
      headers: { "Authorization": `Bearer ${jwtToken}` }
    })
    .then(res => res.json())
    .then(data => {
      if (data && !data.error) setStats(data);
    })
    .catch(err => console.error("Stats compilation failure:", err))
    .finally(() => setLoadingStats(false));
  };

  // --- Circulation Actions ---

  const handleIssueBook = async (bookId: string) => {
    if (!token) return;
    setActionLoadingId(bookId);
    try {
      const res = await fetch("/api/transactions/issue", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ bookId })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not process loan.");

      // Refresh listings
      fetchBooks(token);
      fetchTransactions(token);
      if (user?.role === "admin") fetchStats(token);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleReserveBook = async (bookId: string) => {
    if (!token) return;
    setActionLoadingId(bookId);
    try {
      const res = await fetch("/api/transactions/reserve", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ bookId })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not process reservation.");

      fetchBooks(token);
      fetchTransactions(token);
      if (user?.role === "admin") fetchStats(token);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleReturnBook = async (txId: string) => {
    if (!token) return;
    setActionLoadingId(txId);
    try {
      const res = await fetch(`/api/transactions/return/${txId}`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not process return.");

      fetchBooks(token);
      fetchTransactions(token);
      if (user?.role === "admin") fetchStats(token);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setActionLoadingId(null);
    }
  };

  const handlePayFine = async (txId: string) => {
    if (!token) return;
    setActionLoadingId(txId);
    try {
      const res = await fetch(`/api/transactions/pay-fine/${txId}`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not process payment.");

      fetchTransactions(token);
      if (user?.role === "admin") fetchStats(token);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setActionLoadingId(null);
    }
  };

  const handleCancelReservation = async (txId: string) => {
    if (!token) return;
    setActionLoadingId(txId);
    try {
      const res = await fetch(`/api/transactions/cancel-reservation/${txId}`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not cancel reservation.");

      fetchBooks(token);
      fetchTransactions(token);
      if (user?.role === "admin") fetchStats(token);
    } catch (e: any) {
      alert(e.message);
    } finally {
      setActionLoadingId(null);
    }
  };

  // --- CRUD Actions ---

  const handleCreateBook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setCrudError(null);

    const payload = {
      title: bookTitle,
      author: bookAuthor,
      category: bookCategory,
      isbn: bookIsbn,
      totalCopies: bookCopies,
      location: bookLocation,
      finePerDay: bookFineRate,
      synopsis: bookSynopsis,
      publishedYear: bookYear
    };

    try {
      const res = await fetch("/api/books", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not create book record.");

      // Clear states
      setIsAddingBook(false);
      setBookTitle("");
      setBookAuthor("");
      setBookIsbn("");
      setBookLocation("");
      setBookSynopsis("");
      setBookCopies(3);

      fetchBooks(token);
      fetchStats(token);
    } catch (err: any) {
      setCrudError(err.message);
    }
  };

  const handleEditBookInit = (b: BookType) => {
    setEditingBookId(b.id);
    setBookTitle(b.title);
    setBookAuthor(b.author);
    setBookCategory(b.category);
    setBookIsbn(b.isbn);
    setBookCopies(b.totalCopies);
    setBookLocation(b.location);
    setBookSynopsis(b.synopsis);
    setBookYear(b.publishedYear);
    setBookFineRate(b.finePerDay);
  };

  const handleUpdateBook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !editingBookId) return;
    setCrudError(null);

    const payload = {
      title: bookTitle,
      author: bookAuthor,
      category: bookCategory,
      isbn: bookIsbn,
      totalCopies: bookCopies,
      location: bookLocation,
      finePerDay: bookFineRate,
      synopsis: bookSynopsis,
      publishedYear: bookYear
    };

    try {
      const res = await fetch(`/api/books/${editingBookId}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not update book record.");

      setEditingBookId(null);
      fetchBooks(token);
      fetchStats(token);
    } catch (err: any) {
      setCrudError(err.message);
    }
  };

  const handleDeleteBook = async (id: string) => {
    if (!token) return;
    if (!confirm("Are you sure you want to delete this book from the catalog?")) return;

    try {
      const res = await fetch(`/api/books/${id}`, {
        method: "DELETE",
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Deletion restricted due to outstanding loans.");

      fetchBooks(token);
      fetchStats(token);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleDeleteMember = async (id: string) => {
    if (!token) return;
    if (!confirm("Are you sure you want to deregister this library member account?")) return;

    try {
      const res = await fetch(`/api/members/${id}`, {
        method: "DELETE",
        headers: { "Authorization": `Bearer ${token}` }
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Roster deletion restricted.");

      fetchMembers(token);
      fetchStats(token);
    } catch (err: any) {
      alert(err.message);
    }
  };

  const handleDeleteQuery = async (id: string) => {
    if (!token) return;
    try {
      await fetch(`/api/queries/${id}`, {
        method: "DELETE",
        headers: { "Authorization": `Bearer ${token}` }
      });
      fetchQueries(token);
    } catch (err: any) {
      alert(err.message);
    }
  };

  // --- Query Handlers ---

  const handleSubmitQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setSubmitQueryFeedback(null);

    try {
      const res = await fetch("/api/queries", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ subject: querySubject, message: queryMessage })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setQuerySubject("");
      setQueryMessage("");
      setSubmitQueryFeedback("Query submitted and auto-dispatched to librarian successfully!");
      fetchQueries(token);
    } catch (err: any) {
      setSubmitQueryFeedback(`Error: ${err.message}`);
    }
  };

  const handleRespondQuery = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !respondingQueryId) return;

    try {
      const res = await fetch(`/api/queries/respond/${respondingQueryId}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ response: adminResponseText })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      setAdminResponseText("");
      setRespondingQueryId(null);
      fetchQueries(token);
    } catch (e: any) {
      alert(e.message);
    }
  };

  // --- Profile Handlers ---

  const handleUpdateProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setSubmittingProfile(true);
    setProfileFeedback(null);

    try {
      const res = await fetch("/api/profile/update", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ name: profileName, email: profileEmail })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Profile update failed.");

      setUser(prev => prev ? { ...prev, name: data.user.name, email: data.user.email } : null);
      setProfileFeedback({ type: "success", msg: "Profile particulars updated successfully." });
    } catch (err: any) {
      setProfileFeedback({ type: "error", msg: err.message || "Failed to edit user specifications." });
    } finally {
      setSubmittingProfile(false);
    }
  };

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setPasswordFeedback(null);

    if (newPassword !== confirmNewPassword) {
      setPasswordFeedback({ type: "error", msg: "New passwords do not match." });
      return;
    }

    setSubmittingPassword(true);
    try {
      const res = await fetch("/api/profile/password", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify({ currentPassword, newPassword })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Verification mismatch.");

      setPasswordFeedback({ type: "success", msg: "Password updated successfully." });
      setCurrentPassword("");
      setNewPassword("");
      setConfirmNewPassword("");
    } catch (err: any) {
      setPasswordFeedback({ type: "error", msg: err.message || "Failed to update security credentials." });
    } finally {
      setSubmittingPassword(false);
    }
  };

  // Helper matching colors to departments
  const getCategoryTheme = (category: string) => {
    switch (category) {
      case "Java Development":
        return { bg: "bg-blue-50 text-blue-700 border-blue-200", darkBg: "bg-blue-600" };
      case "Database Systems":
        return { bg: "bg-purple-50 text-purple-700 border-purple-200", darkBg: "bg-purple-600" };
      case "Web Development":
        return { bg: "bg-teal-50 text-teal-700 border-teal-200", darkBg: "bg-teal-600" };
      case "General Aptitude":
        return { bg: "bg-amber-50 text-amber-700 border-amber-200", darkBg: "bg-amber-600" };
      default:
        return { bg: "bg-slate-50 text-slate-700 border-slate-200", darkBg: "bg-slate-600" };
    }
  };

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(val);
  };

  // Catalog filtered and searched listings
  const filteredBooks = books.filter(b => {
    const matchesSearch = b.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          b.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          b.isbn.includes(searchQuery);
    const matchesCategory = filterCategory === "all" || b.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  // Calculate student outstanding fine sum
  const studentTotalFine = transactions
    .filter(t => t.status === "borrowed" && !t.finePaid && t.fineAmount > 0)
    .reduce((sum, t) => sum + t.fineAmount, 0);

  if (!token || !user) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  return (
    <div className="min-h-screen bg-[#fafafa] flex flex-col font-sans antialiased text-slate-800">
      
      {/* PROFESSIONAL PORTAL SYSTEM BAR */}
      <header className="bg-[#1e252b] border-b border-slate-800 shadow-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#fab005] rounded-xl text-slate-950 shadow-inner">
              <svg 
                className="w-6 h-6 stroke-[2]" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
              </svg>
            </div>
            <div>
              <h1 className="text-white font-sans font-extrabold tracking-tight text-lg">Digital Library Records</h1>
              <p className="text-slate-400 text-xs font-mono">Automated Booking & Circulation Desk</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="text-right">
              <div className="flex items-center gap-1.5 justify-end">
                {user.role === "admin" ? (
                  <span className="px-2.5 py-0.5 text-[10px] font-mono font-bold bg-[#fab005] text-slate-950 rounded-full flex items-center gap-1 uppercase tracking-wide">
                    <ShieldCheck className="h-3 w-3" /> Staff Master
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 text-[10px] font-mono font-semibold bg-blue-600 text-white rounded-full flex items-center gap-1 uppercase tracking-wide">
                    <Landmark className="h-3 w-3" /> Member
                  </span>
                )}
                <span className="text-sm text-slate-200 font-bold">{user.name}</span>
              </div>
              <span className="text-xs text-slate-400 font-mono block">{user.email}</span>
            </div>

            <button 
              onClick={handleLogoutClean}
              className="p-2.5 bg-slate-800 text-slate-400 hover:text-white rounded-xl border border-slate-700/60 hover:bg-slate-700 transition-colors focus:outline-none cursor-pointer"
              title="Sign Out"
            >
              <LogOut className="h-4.5 w-4.5" />
            </button>
          </div>

        </div>
      </header>

      {/* DUAL-PRIVILEGES DOCK NAVIGATION MENU */}
      <nav className="bg-white border-b border-slate-200/80 shadow-sm sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex overflow-x-auto py-2.5 gap-2 items-center">
            
            {user.role === "admin" ? (
              // ADMIN CONTROL BAR tabs
              <>
                <button
                  onClick={() => setActiveTab("reports")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === "reports" 
                      ? "bg-[#1e252b] text-[#fab005] shadow" 
                      : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <BarChart2 className="h-4 w-4" /> Reports & Analytics
                </button>

                <button
                  onClick={() => setActiveTab("catalog")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === "catalog" 
                      ? "bg-[#1e252b] text-[#fab005] shadow" 
                      : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <BookOpen className="h-4 w-4" /> Book Inventory
                </button>

                <button
                  onClick={() => setActiveTab("circulation")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === "circulation" 
                      ? "bg-[#1e252b] text-[#fab005] shadow" 
                      : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <Clock className="h-4 w-4" /> Circulation Logs
                </button>

                <button
                  onClick={() => setActiveTab("members")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === "members" 
                      ? "bg-[#1e252b] text-[#fab005] shadow" 
                      : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <Users className="h-4 w-4" /> Membership Roster
                </button>

                <button
                  onClick={() => {
                    setActiveTab("enquiries");
                    setRespondingQueryId(null);
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer relative ${
                    activeTab === "enquiries" 
                      ? "bg-[#1e252b] text-[#fab005] shadow" 
                      : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <Mail className="h-4 w-4" /> Student Enquiries
                  {queries.some(q => q.status === "unread") && (
                    <span className="absolute top-1 right-1 h-2.5 w-2.5 bg-red-500 rounded-full border-2 border-white animate-pulse"></span>
                  )}
                </button>
              </>
            ) : (
              // STUDENT NAVIGATION BAR TABS
              <>
                <button
                  onClick={() => {
                    setActiveTab("catalog");
                    setEditingBookId(null);
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === "catalog" 
                      ? "bg-[#1e252b] text-[#fab005] shadow" 
                      : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <BookOpen className="h-4 w-4" /> Book Catalog
                </button>

                <button
                  onClick={() => setActiveTab("my_loans")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer relative ${
                    activeTab === "my_loans" 
                      ? "bg-[#1e252b] text-[#fab005] shadow" 
                      : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <Clock className="h-4 w-4" /> Active Borrowings
                  {transactions.some(t => t.status === "borrowed" && t.fineAmount > 0) && (
                    <span className="absolute top-1 right-1 h-2.5 w-2.5 bg-amber-500 rounded-full border-2 border-white"></span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab("my_reservations")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === "my_reservations" 
                      ? "bg-[#1e252b] text-[#fab005] shadow" 
                      : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <Bookmark className="h-4 w-4" /> Holds & Reservations
                </button>

                <button
                  onClick={() => setActiveTab("contact")}
                  className={`px-4 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
                    activeTab === "contact" 
                      ? "bg-[#1e252b] text-[#fab005] shadow" 
                      : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
                  }`}
                >
                  <Mail className="h-4 w-4" /> Mail Librarian
                </button>
              </>
            )}

            <span className="h-5 w-px bg-slate-350 mx-2 block shrink-0"></span>

            <button
              onClick={() => setActiveTab("profile")}
              className={`px-4 py-2 rounded-xl text-xs font-bold font-mono uppercase tracking-widest flex items-center gap-2 transition-all cursor-pointer ${
                activeTab === "profile" 
                  ? "bg-[#1e252b] text-[#fab005] shadow" 
                  : "text-slate-500 hover:text-slate-900 hover:bg-slate-100"
              }`}
            >
              <Settings className="h-4 w-4" /> My Credentials
            </button>

          </div>
        </div>
      </nav>

      {/* CORE WORKSPACE CONTENT AREA WITH GENTLE ANIMATION TRANSITIONS */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <AnimatePresence mode="wait">
          
          {/* ========================================================== */}
          {/* STAFF METRICS DASHBOARD SECTION */}
          {/* ========================================================== */}
          {activeTab === "reports" && user.role === "admin" && (
            <motion.div
              key="stats_view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-extrabold tracking-tight text-slate-900">Automation Report Board</h2>
                  <p className="text-xs text-slate-500 mt-1">Compiled real-time status details of books, loans, outstanding penalties, and query lists.</p>
                </div>
                <button
                  onClick={() => {
                    fetchStats(token);
                    fetchTransactions(token);
                  }}
                  className="px-3.5 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  <RefreshCw className="h-3.5 w-3.5" /> Force Audit Recalculation
                </button>
              </div>

              {loadingStats ? (
                <div className="py-20 text-center text-slate-500 font-mono text-sm leading-relaxed">
                  <div className="inline-block h-6 w-6 border-2 border-slate-900 border-t-transparent rounded-full animate-spin mb-2"></div>
                  <p>Synthesizing current database indicators...</p>
                </div>
              ) : stats ? (
                <div id="stats_panel" className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                  
                  {/* Total Copies */}
                  <div className="p-5 bg-white border border-slate-200/80 rounded-2xl shadow-sm flex items-center gap-4">
                    <div className="p-3 bg-blue-50 text-blue-600 rounded-xl border border-blue-100">
                      <BookOpen className="h-6 w-6" />
                    </div>
                    <div>
                      <span className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Total Volumes</span>
                      <span className="text-3xl font-extrabold text-slate-800 leading-none">{stats.totalBooks}</span>
                      <span className="text-[10px] text-slate-400 block mt-1">across {stats.uniqueTitles} titles</span>
                    </div>
                  </div>

                  {/* Active Loans */}
                  <div className="p-5 bg-white border border-slate-200/80 rounded-2xl shadow-sm flex items-center gap-4">
                    <div className="p-3 bg-purple-50 text-purple-600 rounded-xl border border-purple-100">
                      <Clock className="h-6 w-6" />
                    </div>
                    <div>
                      <span className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-400">In Circulation</span>
                      <span className="text-3xl font-extrabold text-slate-800 leading-none">{stats.activeBorrows}</span>
                      <span className="text-[10px] text-slate-400 block mt-1">lent to active members</span>
                    </div>
                  </div>

                  {/* Outstanding Fines */}
                  <div className="p-5 bg-white border border-slate-200/80 rounded-2xl shadow-sm flex items-center gap-4">
                    <div className={`p-3 rounded-xl border ${stats.unpaidFines > 0 ? "bg-red-50 text-red-600 border-red-100" : "bg-emerald-50 text-emerald-600 border-emerald-100"}`}>
                      <CircleDollarSign className="h-6 w-6" />
                    </div>
                    <div>
                      <span className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Fines Accumulation</span>
                      <span className="text-3xl font-extrabold text-slate-800 leading-none">{formatCurrency(stats.unpaidFines)}</span>
                      <span className="text-[10px] text-slate-400 block mt-1">awaiting member payoff</span>
                    </div>
                  </div>

                  {/* Registered Base */}
                  <div className="p-5 bg-white border border-slate-200/80 rounded-2xl shadow-sm flex items-center gap-4">
                    <div className="p-3 bg-teal-50 text-teal-600 rounded-xl border border-teal-100">
                      <Users className="h-6 w-6" />
                    </div>
                    <div>
                      <span className="block text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Library Members</span>
                      <span className="text-3xl font-extrabold text-slate-800 leading-none">{stats.totalMembers}</span>
                      <span className="text-[10px] text-slate-400 block mt-1">enrolled student profiles</span>
                    </div>
                  </div>

                </div>
              ) : null}

              {/* QUICK HIGHLIGHTS BENTO SECTION FOR ADMIN */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pt-2">
                <div className="lg:col-span-8 bg-white border border-slate-200/80 p-6 rounded-2xl shadow-sm space-y-4">
                  <h3 className="font-sans font-extrabold text-slate-950 text-base flex items-center gap-2">
                    <Landmark className="h-5 w-5 text-[#fab005]" /> Rapid System Auditing Summary
                  </h3>
                  
                  <div className="text-sm text-slate-600 leading-relaxed space-y-2">
                    <p>
                      This automation system securely handles client-side queries and updates them immediately to a persistent server. As detailed on the assignment specifications:
                    </p>
                    <ul className="list-disc pl-5 mt-2 space-y-1.5 text-slate-600">
                      <li><strong>Automated Calculation:</strong> Overdue penalties are dynamically calculated on the server side at a fine rate relative to the book instance when daily due limits pass.</li>
                      <li><strong>Advance Hold Mechanism:</strong> When copies reach 0, normal users cannot bypass circulation. Setting an advance booking slots details onto reservations. Once the book is checked back in, it routes instantly to the reservation holder.</li>
                      <li><strong>No Hardcoded Watermarks:</strong> Visually styled directly to suit the original presenter theme.</li>
                    </ul>
                  </div>

                  <div className="bg-[#fafafa] border border-slate-200 p-4 rounded-xl flex items-center gap-3">
                    <CheckCircle className="text-emerald-500 h-5 w-5 shrink-0" />
                    <span className="text-xs font-mono text-slate-500">Database server status is <strong className="text-emerald-600 font-semibold font-sans">Active & Synchronized</strong> with 6 mock book titles pre-seeded.</span>
                  </div>
                </div>

                <div className="lg:col-span-4 bg-white border border-slate-200/80 p-6 rounded-2xl shadow-sm flex flex-col justify-between">
                  <div>
                    <h3 className="font-sans font-bold text-slate-900 text-sm tracking-wider uppercase font-mono">Immediate Shortcuts</h3>
                    <p className="text-xs text-slate-500 mt-1">Fast jump triggers to handle various digitization processes.</p>
                  </div>

                  <div className="space-y-2 mt-4">
                    <button 
                      onClick={() => setActiveTab("catalog")}
                      className="w-full text-left p-3 hover:bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs font-semibold cursor-pointer"
                    >
                      <span>New Book Registration Form</span>
                      <Plus className="h-4 w-4 text-[#fab005]" />
                    </button>
                    <button 
                      onClick={() => setActiveTab("circulation")}
                      className="w-full text-left p-3 hover:bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs font-semibold cursor-pointer"
                    >
                      <span>Record Book Check-In</span>
                      <Clock className="h-4 w-4 text-[#fab005]" />
                    </button>
                    <button 
                      onClick={() => setActiveTab("enquiries")}
                      className="w-full text-left p-3 hover:bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs font-semibold cursor-pointer"
                    >
                      <span>Respond to Active Queries</span>
                      <Mail className="h-4 w-4 text-[#fab005]" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* ========================================================== */}
          {/* BOOK CATALOG GRID VIEW (STUDENTS & ADMINS) */}
          {/* ========================================================== */}
          {activeTab === "catalog" && (
            <motion.div
              key="catalog_view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              
              {/* Filter system and CRUD initialization */}
              <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 bg-white border border-slate-200/80 p-4 rounded-2xl shadow-sm">
                
                <div className="flex-grow max-w-lg relative">
                  <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                    <Search className="h-4 w-4" />
                  </span>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search by Title, Author name, or standard ISBN..."
                    className="w-full bg-[#fafafa] border border-slate-200 rounded-xl pl-9 pr-4 py-2.5 text-sm focus:outline-none focus:border-[#fab005] transition-colors leading-relaxed"
                  />
                </div>

                <div className="flex flex-wrap items-center gap-3">
                  
                  <div className="flex items-center gap-1 bg-slate-100 border border-slate-200 p-1 rounded-xl">
                    <button
                      onClick={() => setFilterCategory("all")}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-colors cursor-pointer ${
                        filterCategory === "all" ? "bg-[#1e252b] text-white" : "text-slate-500 hover:text-slate-900"
                      }`}
                    >
                      All
                    </button>
                    <button
                      onClick={() => setFilterCategory("Java Development")}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-colors cursor-pointer ${
                        filterCategory === "Java Development" ? "bg-[#1e252b] text-[#fab005]" : "text-slate-500 hover:text-slate-900"
                      }`}
                    >
                      Java
                    </button>
                    <button
                      onClick={() => setFilterCategory("Database Systems")}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-colors cursor-pointer ${
                        filterCategory === "Database Systems" ? "bg-[#1e252b] text-[#fab005]" : "text-slate-500 hover:text-slate-900"
                      }`}
                    >
                      Databases
                    </button>
                    <button
                      onClick={() => setFilterCategory("Web Development")}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono uppercase tracking-wider transition-colors cursor-pointer ${
                        filterCategory === "Web Development" ? "bg-[#1e252b] text-[#fab005]" : "text-slate-500 hover:text-slate-900"
                      }`}
                    >
                      Web
                    </button>
                  </div>

                  {user.role === "admin" && !isAddingBook && (
                    <button
                      onClick={() => {
                        setEditingBookId(null);
                        setIsAddingBook(true);
                      }}
                      className="px-4 py-2.5 bg-[#fab005] hover:bg-amber-400 text-slate-950 font-sans font-bold text-xs uppercase tracking-wider rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                    >
                      <Plus className="h-4 w-4" /> Create Record
                    </button>
                  )}

                </div>

              </div>

              {/* BOOK WRITING/CREATING CRUD FORM PANEL */}
              {user.role === "admin" && (isAddingBook || editingBookId) && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.98 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-white border-2 border-[#fab005]/40 p-6 rounded-2xl shadow-sm space-y-4"
                >
                  <div className="flex items-center justify-between border-b border-slate-200 pb-3">
                    <h3 className="font-sans font-extrabold text-slate-900 text-base">
                      {editingBookId ? `Modify Catalog Series • ID: ${editingBookId}` : "Register New Book Volume Record"}
                    </h3>
                    <button 
                      onClick={() => {
                        setIsAddingBook(false);
                        setEditingBookId(null);
                        setCrudError(null);
                      }}
                      className="p-1 px-2 hover:bg-slate-100 rounded text-xs text-slate-400 hover:text-slate-800 font-mono focus:outline-none cursor-pointer"
                    >
                      Cancel Form [ESC]
                    </button>
                  </div>

                  {crudError && (
                    <div className="p-3 bg-red-50 border border-red-200 text-xs text-red-600 rounded-lg">
                      {crudError}
                    </div>
                  )}

                  <form onSubmit={editingBookId ? handleUpdateBook : handleCreateBook} className="grid grid-cols-1 md:grid-cols-12 gap-4">
                    
                    <div className="md:col-span-6 space-y-1">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Book Title</label>
                      <input 
                        type="text" 
                        required
                        value={bookTitle}
                        onChange={(e) => setBookTitle(e.target.value)}
                        placeholder="E.g., Spring Boot in Action"
                        className="w-full bg-[#fafafa] border border-slate-250 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#fab005] transition-colors"
                      />
                    </div>

                    <div className="md:col-span-4 space-y-1">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Primary Author</label>
                      <input 
                        type="text" 
                        required
                        value={bookAuthor}
                        onChange={(e) => setBookAuthor(e.target.value)}
                        placeholder="E.g., Craig Walls"
                        className="w-full bg-[#fafafa] border border-slate-250 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#fab005] transition-colors"
                      />
                    </div>

                    <div className="md:col-span-2 space-y-1">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Department</label>
                      <select
                        value={bookCategory}
                        onChange={(e) => setBookCategory(e.target.value)}
                        className="w-full bg-[#fafafa] border border-slate-255 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#fab005] transition-colors"
                      >
                        <option value="Java Development">Java</option>
                        <option value="Database Systems">Databases</option>
                        <option value="Web Development">Web</option>
                        <option value="General Aptitude">Aptitude</option>
                      </select>
                    </div>

                    <div className="md:col-span-3 space-y-1">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">ISBN Standard</label>
                      <input 
                        type="text" 
                        required
                        value={bookIsbn}
                        onChange={(e) => setBookIsbn(e.target.value)}
                        placeholder="E.g., 978-0134670942"
                        className="w-full bg-[#fafafa] border border-slate-250 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#fab005] transition-colors font-mono"
                      />
                    </div>

                    <div className="md:col-span-2 space-y-1">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Total Copies</label>
                      <input 
                        type="number" 
                        required
                        min="1"
                        max="20"
                        value={bookCopies}
                        onChange={(e) => setBookCopies(Number(e.target.value))}
                        className="w-full bg-[#fafafa] border border-slate-250 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#fab005] transition-colors"
                      />
                    </div>

                    <div className="md:col-span-3 space-y-1">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Storage Location Shelf</label>
                      <input 
                        type="text" 
                        required
                        value={bookLocation}
                        onChange={(e) => setBookLocation(e.target.value)}
                        placeholder="E.g., Shelf A-6"
                        className="w-full bg-[#fafafa] border border-slate-250 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#fab005] transition-colors font-sans"
                      />
                    </div>

                    <div className="md:col-span-2 space-y-1">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Release Year</label>
                      <input 
                        type="number" 
                        required
                        value={bookYear}
                        onChange={(e) => setBookYear(Number(e.target.value))}
                        className="w-full bg-[#fafafa] border border-slate-250 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#fab005] transition-colors font-mono"
                      />
                    </div>

                    <div className="md:col-span-2 space-y-1">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Daily Fine ($)</label>
                      <input 
                        type="number" 
                        step="0.05"
                        required
                        value={bookFineRate}
                        onChange={(e) => setBookFineRate(Number(e.target.value))}
                        className="w-full bg-[#fafafa] border border-slate-250 rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-[#fab005] transition-colors font-mono"
                      />
                    </div>

                    <div className="md:col-span-12 space-y-1">
                      <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Synopsis Synopsis Brief</label>
                      <textarea
                        required
                        rows={2}
                        value={bookSynopsis}
                        onChange={(e) => setBookSynopsis(e.target.value)}
                        placeholder="Describe the content coverages of this book..."
                        className="w-full bg-[#fafafa] border border-slate-250 rounded-lg p-3 text-sm focus:outline-none focus:border-[#fab005] transition-colors"
                      />
                    </div>

                    <div className="md:col-span-12 flex justify-end gap-2 pt-2">
                      <button 
                        type="submit"
                        className="px-5 py-2.5 bg-slate-900 border border-slate-900 hover:bg-slate-850 text-[#fab005] font-sans font-bold text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer"
                      >
                        {editingBookId ? "Save Modifications" : "Publish Book Volume"}
                      </button>
                    </div>

                  </form>
                </motion.div>
              )}

              {/* LOADING INDICATOR */}
              {loadingBooks ? (
                <div className="py-24 text-center text-slate-500 font-mono text-xs">
                  <div className="inline-block h-6 w-6 border-2 border-slate-900 border-t-transparent rounded-full animate-spin mb-2"></div>
                  <p>Searching automated library catalogs...</p>
                </div>
              ) : filteredBooks.length === 0 ? (
                <div className="py-16 text-center text-slate-400 font-mono text-sm border-2 border-dashed border-slate-200 bg-white rounded-2xl">
                  No matching books found in active indices. Try adjusting your parameters.
                </div>
              ) : (
                <div id="books_grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredBooks.map((b) => {
                    const theme = getCategoryTheme(b.category);
                    const isInStock = b.availableCopies > 0;
                    
                    return (
                      <motion.div
                        key={b.id}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className={`bg-white border rounded-2xl shadow-sm p-5 space-y-4 relative flex flex-col justify-between transition-all ${
                          editingBookId === b.id ? "border-[#fab005] ring-2 ring-[#fab005]/20" : "border-slate-200"
                        }`}
                      >
                        
                        <div className="space-y-3">
                          
                          {/* Tags block */}
                          <div className="flex items-center justify-between gap-1">
                            <span className={`px-2.5 py-0.5 rounded-lg text-[9px] font-mono font-bold tracking-widest uppercase border ${theme.bg}`}>
                              {b.category}
                            </span>
                            
                            {/* Stock Indicator */}
                            {isInStock ? (
                              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[9px] font-mono font-bold uppercase tracking-wider border border-emerald-100 rounded-lg">
                                In Stock
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 bg-red-50 text-red-700 text-[9px] font-mono font-bold uppercase tracking-wider border border-red-100 rounded-lg">
                                Out of Stock
                              </span>
                            )}
                          </div>

                          <div>
                            <h4 className="font-sans font-extrabold text-slate-900 text-base leading-snug tracking-tight text-left">
                              {b.title}
                            </h4>
                            <span className="text-xs text-slate-500 font-sans block mt-1">
                              by <strong className="text-slate-850 font-semibold">{b.author}</strong> • {b.publishedYear}
                            </span>
                          </div>

                          <p className="text-xs text-[#526071] leading-relaxed line-clamp-3">
                            {b.synopsis}
                          </p>

                          {/* Technical particulars panel */}
                          <div className="grid grid-cols-2 gap-2 p-2.5 bg-neutral-50/70 border border-slate-200/80 rounded-xl font-mono text-[10px] text-slate-500">
                            <div className="flex items-center gap-1">
                              <Tag className="h-3 w-3 inline text-slate-400 shrink-0" />
                              <span>ISBN: {b.isbn}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="h-3 w-3 inline text-slate-400 shrink-0" />
                              <span>Shelf: {b.location}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="h-3 w-3 inline text-slate-400 shrink-0" />
                              <span>Holds: 7 Days max</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <CircleDollarSign className="h-3 w-3 inline text-slate-400 shrink-0" />
                              <span>Fine: {formatCurrency(b.finePerDay)}/day</span>
                            </div>
                          </div>

                        </div>

                        <div className="pt-4 border-t border-slate-100/80 space-y-3.5">
                          
                          {/* Available copies metrics bar */}
                          <div>
                            <div className="flex justify-between items-center text-[10px] tracking-wider uppercase font-mono font-bold text-slate-450 mb-1.5">
                              <span>Physical Availability</span>
                              <span className={isInStock ? "text-slate-700" : "text-red-600"}>
                                {b.availableCopies} of {b.totalCopies} Vol.
                              </span>
                            </div>
                            {/* Visual Progress bar representation */}
                            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                              <div 
                                className={`h-full rounded-full transition-all ${isInStock ? theme.darkBg : "bg-red-500"}`} 
                                style={{ width: `${(b.availableCopies / b.totalCopies) * 100}%` }}
                              />
                            </div>
                          </div>

                          {/* Active Circulation Control Buttons */}
                          <div className="flex items-center justify-between gap-2 pt-1">
                            
                            {user.role === "admin" ? (
                              // STAFF BOOK MANAGEMENT CONTROLS
                              <div className="flex gap-2 w-full">
                                <button
                                  onClick={() => handleEditBookInit(b)}
                                  className="flex-1 py-1.5 bg-slate-100 hover:bg-slate-200 border border-slate-250 text-slate-700 font-sans font-bold text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-1 transition-colors cursor-pointer"
                                >
                                  <Edit2 className="h-3 w-3" /> Edit Book
                                </button>
                                <button
                                  onClick={() => handleDeleteBook(b.id)}
                                  className="px-2.5 py-1.5 bg-red-50 hover:bg-red-100 border border-red-200 text-red-600 rounded-lg transition-colors cursor-pointer"
                                  title="Purge Record"
                                >
                                  <Trash2 className="h-4.5 w-4.5" />
                                </button>
                              </div>
                            ) : (
                              // STUDENT MEMBERS RECKONINGS CONTROLS
                              <div className="w-full">
                                {isInStock ? (
                                  <button
                                    onClick={() => handleIssueBook(b.id)}
                                    disabled={actionLoadingId === b.id}
                                    className="w-full py-1.5 bg-slate-900 border border-slate-900 hover:bg-slate-850 text-[#fab005] font-sans font-bold text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-1 transition-all cursor-pointer disabled:opacity-50"
                                  >
                                    {actionLoadingId === b.id ? (
                                      <span className="inline-block h-4 w-4 border-2 border-amber-400 border-t-transparent rounded-full animate-spin"></span>
                                    ) : (
                                      <>
                                        <BookOpen className="h-4 w-4" /> Issue This Book
                                      </>
                                    )}
                                  </button>
                                ) : (
                                  <button
                                    onClick={() => handleReserveBook(b.id)}
                                    disabled={actionLoadingId === b.id}
                                    className="w-full py-1.5 bg-slate-800/85 hover:bg-slate-750 text-amber-500 hover:text-amber-400 font-sans font-semibold text-xs uppercase tracking-wider rounded-lg flex items-center justify-center gap-1.5 transition-all cursor-pointer border border-slate-750 disabled:opacity-50"
                                  >
                                    {actionLoadingId === b.id ? (
                                      <span className="inline-block h-4 w-4 border-2 border-amber-400 border-t-transparent rounded-full animate-spin"></span>
                                    ) : (
                                      <>
                                        <Sparkles className="h-4 w-4" /> Advance Reservation
                                      </>
                                    )}
                                  </button>
                                )}
                              </div>
                            )}

                          </div>

                        </div>

                      </motion.div>
                    );
                  })}
                </div>
              )}

            </motion.div>
          )}

          {/* ========================================================== */}
          {/* USER ACTIVE LOANS SYSTEM BAR (STUDENT PORTAL) */}
          {/* ========================================================== */}
          {activeTab === "my_loans" && user.role === "user" && (
            <motion.div
              key="my_loans_view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div>
                <h2 className="text-2xl font-extrabold tracking-tight text-slate-900">My Active Borrowings</h2>
                <p className="text-xs text-slate-500 mt-1">Keep track of books currently checked out. Return items before deadline of 14 days to preserve fine margins.</p>
              </div>

              {studentTotalFine > 0 && (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0" />
                    <span className="text-sm font-sans text-amber-800">
                      You have an outstanding accrued fine balance of <strong className="text-black font-extrabold">{formatCurrency(studentTotalFine)}</strong> due to overdue checkouts. Use the digital gateways inside logs to settle.
                    </span>
                  </div>
                </div>
              )}

              {loadingTransactions ? (
                <div className="py-20 text-center font-mono text-xs text-slate-500">
                  Compiling loan ledgers...
                </div>
              ) : transactions.filter(t => t.status === "borrowed").length === 0 ? (
                <div className="py-16 text-center text-slate-400 font-mono text-sm border bg-white rounded-2xl">
                  You have no books checked out under your student profile presently. Browse the catalogue to issue a volume!
                </div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-[#1e252b] text-white border-b border-slate-800 text-[10px] uppercase font-mono font-bold tracking-wider">
                          <th className="p-4">Reference Book</th>
                          <th className="p-4">Issue Date</th>
                          <th className="p-4">Due Date</th>
                          <th className="p-4">Overdue Fine</th>
                          <th className="p-4 text-right">Circulation Desk Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-150 text-sm font-sans text-slate-700">
                        {transactions.filter(t => t.status === "borrowed").map((t) => {
                          const isOverdue = new Date() > new Date(t.dueDate);
                          
                          return (
                            <tr key={t.id} className="hover:bg-slate-50">
                              <td className="p-4 font-bold text-slate-900">{t.bookTitle}</td>
                              <td className="p-4 font-mono text-xs text-slate-500">
                                {new Date(t.issueDate).toLocaleDateString()}
                              </td>
                              <td className="p-4">
                                <span className={`font-mono text-xs ${isOverdue ? "text-red-600 font-bold" : "text-slate-500"}`}>
                                  {new Date(t.dueDate).toLocaleDateString()} {isOverdue && "(Overdue)"}
                                </span>
                              </td>
                              <td className="p-4 font-mono text-xs">
                                {t.fineAmount > 0 ? (
                                  <span className="text-red-600 font-semibold">{formatCurrency(t.fineAmount)}</span>
                                ) : (
                                  <span className="text-slate-400">None</span>
                                )}
                              </td>
                              <td className="p-3 text-right space-x-2">
                                
                                {t.fineAmount > 0 && !t.finePaid && (
                                  <button
                                    onClick={() => handlePayFine(t.id)}
                                    disabled={actionLoadingId === t.id}
                                    className="px-3 py-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg transition-colors cursor-pointer shrink-0 disabled:opacity-50"
                                  >
                                    Pay Fine
                                  </button>
                                )}

                                <button
                                  onClick={() => handleReturnBook(t.id)}
                                  disabled={actionLoadingId === t.id}
                                  className="px-3.5 py-1.5 bg-slate-900 border border-slate-900 hover:bg-slate-800 text-[#fab005] font-bold text-xs uppercase tracking-wider rounded-lg transition-all cursor-pointer shrink-0 disabled:opacity-50"
                                >
                                  {actionLoadingId === t.id ? (
                                    <span className="inline-block h-3.5 w-3.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin"></span>
                                  ) : (
                                    "Check In"
                                  )}
                                </button>
                                
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

            </motion.div>
          )}

          {/* ========================================================== */}
          {/* USER ACTIVE RESERVATIONS / HOLDS (STUDENT PORTAL) */}
          {/* ========================================================== */}
          {activeTab === "my_reservations" && user.role === "user" && (
            <motion.div
              key="my_reservations_view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div>
                <h2 className="text-2xl font-extrabold tracking-tight text-slate-900">Holds & Reservations</h2>
                <p className="text-xs text-slate-500 mt-1">Advance placement requests on out-of-stock items. As soon as another member check in, the transaction upgrades immediately to Active Loan.</p>
              </div>

              {loadingTransactions ? (
                <div className="py-20 text-center font-mono text-xs text-slate-500">
                  Filtering holds registry...
                </div>
              ) : transactions.filter(t => t.status === "reserved").length === 0 ? (
                <div className="py-16 text-center text-slate-400 font-mono text-sm border bg-white rounded-2xl">
                  You have no pending reservations at this moment.
                </div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-[#1e252b] text-white border-b border-slate-800 text-[10px] uppercase font-mono font-bold tracking-wider">
                          <th className="p-4">Reference Book</th>
                          <th className="p-4">Requested hold Reservation Date</th>
                          <th className="p-4">Hold Hold Expiry Limit</th>
                          <th className="p-4 text-right">Circulation Desk Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-150 text-sm font-sans text-slate-700">
                        {transactions.filter(t => t.status === "reserved").map((t) => (
                          <tr key={t.id} className="hover:bg-slate-50">
                            <td className="p-4 font-bold text-slate-900">{t.bookTitle}</td>
                            <td className="p-4 font-mono text-xs text-slate-500">
                              {new Date(t.issueDate).toLocaleDateString()}
                            </td>
                            <td className="p-4 font-mono text-xs text-slate-500">
                              {new Date(t.dueDate).toLocaleDateString()}
                            </td>
                            <td className="p-3 text-right">
                              <button
                                onClick={() => handleCancelReservation(t.id)}
                                disabled={actionLoadingId === t.id}
                                className="px-3.5 py-1.5 bg-red-50 hover:bg-red-100 border border-red-100 text-red-650 font-semibold text-xs uppercase tracking-wider rounded-lg transition-colors cursor-pointer"
                              >
                                {actionLoadingId === t.id ? (
                                  <span className="inline-block h-3.5 w-3.5 border-2 border-red-500 border-t-transparent rounded-full animate-spin"></span>
                                ) : (
                                  "Cancel Hold"
                                )}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

            </motion.div>
          )}

          {/* ========================================================== */}
          {/* USER SUBMIT QUERY (STUDENT PORTAL) */}
          {/* ========================================================== */}
          {activeTab === "contact" && user.role === "user" && (
            <motion.div
              key="contact_view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-8"
            >
              
              {/* Form Input fields */}
              <div className="lg:col-span-5 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
                <div>
                  <h2 className="text-xl font-extrabold text-slate-900">Inquiry to Librarian</h2>
                  <p className="text-xs text-slate-500 mt-1">Have a bookkeeping request, suggesting new books, or fine disputes? Submit an inquiry securely.</p>
                </div>

                {submitQueryFeedback && (
                  <div className={`p-3.5 rounded-xl text-xs ${submitQueryFeedback.startsWith("Error") ? "bg-red-50 text-red-600 border border-red-150" : "bg-emerald-50 text-emerald-700 border border-emerald-150"}`}>
                    {submitQueryFeedback}
                  </div>
                )}

                <form onSubmit={handleSubmitQuery} className="space-y-4">
                  
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Mail Subject</label>
                    <input
                      type="text"
                      required
                      value={querySubject}
                      onChange={(e) => setQuerySubject(e.target.value)}
                      placeholder="E.g., Fine Dispute / Spring Book Suggestions"
                      className="w-full bg-[#fafafa] border border-slate-250 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-[#fab005] transition-colors"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Inquiry Message</label>
                    <textarea
                      required
                      rows={5}
                      value={queryMessage}
                      onChange={(e) => setQueryMessage(e.target.value)}
                      placeholder="Type details in detail to mail the library administration desk..."
                      className="w-full bg-[#fafafa] border border-slate-250 rounded-xl p-3.5 text-sm focus:outline-none focus:border-[#fab005] transition-colors leading-relaxed"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-2.5 bg-slate-900 hover:bg-slate-800 text-[#fab005] font-sans font-bold text-xs uppercase tracking-wider rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Send className="h-4 w-4" /> Transit Mail Envelope
                  </button>

                </form>
              </div>

              {/* Inquiry list & response logs */}
              <div className="lg:col-span-7 space-y-4">
                <h3 className="font-sans font-extrabold text-slate-900 text-lg">My Historical Enquiries</h3>
                
                {loadingQueries ? (
                  <div className="py-12 text-center text-slate-500 font-mono text-xs">
                    Accessing personal email transmissions...
                  </div>
                ) : queries.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-xs font-mono border-2 border-dashed border-slate-200 bg-white rounded-2xl">
                    No historic queries registered under this profile index.
                  </div>
                ) : (
                  <div className="space-y-4">
                    {queries.map((q) => (
                      <div key={q.id} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-xs font-sans font-bold text-slate-900">{q.subject}</span>
                          <div>
                            {q.status === "replied" ? (
                              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[9px] font-mono font-bold uppercase tracking-wider border border-emerald-150 rounded-lg">
                                Replied
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 bg-slate-100 text-slate-650 text-[9px] font-mono font-bold uppercase tracking-wider border border-slate-200 rounded-lg">
                                Received / Dispatching
                              </span>
                            )}
                          </div>
                        </div>

                        <p className="text-xs text-slate-600 bg-neutral-50/50 p-2.5 rounded-lg font-mono leading-relaxed">
                          {q.message}
                        </p>

                        {q.response && (
                          <div className="p-3.5 bg-slate-50 border-l-[3px] border-[#fab005] rounded-r-xl space-y-1 text-xs">
                            <div className="flex items-center gap-1.5 text-[10px] uppercase font-mono tracking-wider font-bold text-[#b58000]">
                              <span>Chief Librarian Response Office</span>
                            </div>
                            <p className="text-slate-800 leading-relaxed italic">{q.response}</p>
                          </div>
                        )}

                        <span className="text-[10px] text-slate-400 font-mono block mt-1">
                          Delivered: {new Date(q.createdAt).toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>

            </motion.div>
          )}

          {/* ========================================================== */}
          {/* GENERAL CIRCULATION LOGS AUDITS (ADMIN PORTAL) */}
          {/* ========================================================== */}
          {activeTab === "circulation" && user.role === "admin" && (
            <motion.div
              key="circulation_logs_view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div className="flex items-center justify-between gap-4">
                <div>
                  <h2 className="text-2xl font-extrabold tracking-tight text-slate-900">Member Circulation Logs</h2>
                  <p className="text-xs text-slate-500 mt-1">A professional ledger of all historical and active loan transactions across the digital network.</p>
                </div>
                <button
                  onClick={() => fetchTransactions(token)}
                  className="px-3 py-1.5 bg-slate-100 border border-slate-300 rounded-lg text-xs font-semibold hover:bg-slate-250 cursor-pointer flex items-center gap-1.5 transition-colors"
                >
                  <RefreshCw className="h-3.5 w-3.5" /> Reload logs
                </button>
              </div>

              {loadingTransactions ? (
                <div className="py-20 text-center font-mono text-xs text-slate-400">
                  Downloading general ledger accounts...
                </div>
              ) : transactions.length === 0 ? (
                <div className="py-16 text-center text-slate-400 font-mono text-sm border bg-white rounded-2xl">
                  No registered loan or予約 records found in circulation books.
                </div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-[#1e252b] text-white border-b border-slate-800 text-[10px] uppercase font-mono font-bold tracking-wider">
                          <th className="p-4">Reference Book</th>
                          <th className="p-4">Member Name</th>
                          <th className="p-4">Standard Issue Date</th>
                          <th className="p-4">Check-In Deadline</th>
                          <th className="p-4">Fines / Returns Status</th>
                          <th className="p-4 text-right">Circulation Control Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-150 text-sm font-sans text-slate-705">
                        {transactions.map((t) => {
                          const isOverdue = t.status === "borrowed" && new Date() > new Date(t.dueDate);
                          
                          return (
                            <tr key={t.id} className="hover:bg-slate-50">
                              <td className="p-4 font-bold text-slate-900">{t.bookTitle}</td>
                              <td className="p-4 font-sans text-slate-600">{t.userName}</td>
                              <td className="p-4 font-mono text-xs text-slate-500">
                                {new Date(t.issueDate).toLocaleDateString()}
                              </td>
                              <td className="p-4">
                                <span className="font-mono text-xs text-slate-500">
                                  {new Date(t.dueDate).toLocaleDateString()}
                                </span>
                              </td>
                              <td className="p-4">
                                <div className="flex flex-col gap-0.5">
                                  {t.status === "borrowed" && (
                                    <span className="px-2 py-0.5 bg-purple-50 text-purple-700 text-[9px] font-mono font-bold uppercase tracking-wider rounded-lg border border-purple-100 max-w-max">
                                      Active Loan
                                    </span>
                                  )}
                                  {t.status === "returned" && (
                                    <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[9px] font-mono font-bold uppercase tracking-wider rounded-lg border border-emerald-100 max-w-max">
                                      Returned On Due
                                    </span>
                                  )}
                                  {t.status === "reserved" && (
                                    <span className="px-2 py-0.5 bg-amber-50 text-amber-700 text-[9px] font-mono font-bold uppercase tracking-wider rounded-lg border border-amber-100 max-w-max">
                                      Hold Placement active
                                    </span>
                                  )}

                                  {/* Overdue alert panel */}
                                  {isOverdue && (
                                    <span className="text-[10px] text-red-650 font-semibold font-mono">
                                      OVERDUE PENALTY! fine: {formatCurrency(t.fineAmount)}
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="p-3 text-right">
                                {t.status === "borrowed" && (
                                  <button
                                    onClick={() => handleReturnBook(t.id)}
                                    disabled={actionLoadingId === t.id}
                                    className="px-3 py-1.5 bg-slate-900 border border-slate-900 text-[#fab005] font-bold text-xs uppercase tracking-wider rounded-lg transition-colors cursor-pointer disabled:opacity-50 inline-flex items-center justify-center min-w-[100px]"
                                  >
                                    {actionLoadingId === t.id ? (
                                      <span className="inline-block h-3.5 w-3.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin"></span>
                                    ) : (
                                      "Force Return"
                                    )}
                                  </button>
                                )}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

            </motion.div>
          )}

          {/* ========================================================== */}
          {/* MEMBERSHIP ROSTER LIST (ADMIN PORTAL) */}
          {/* ========================================================== */}
          {activeTab === "members" && user.role === "admin" && (
            <motion.div
              key="members_view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div>
                <h2 className="text-2xl font-extrabold tracking-tight text-slate-900">Membership Roster Directory</h2>
                <p className="text-xs text-slate-500 mt-1">Manage database index accounts for enrolled library members.</p>
              </div>

              {loadingMembers ? (
                <div className="py-20 text-center font-mono text-xs text-slate-400">
                  Retrieving subscriber records...
                </div>
              ) : members.length === 0 ? (
                <div className="py-16 text-center text-slate-400 font-mono text-sm border bg-white rounded-2xl">
                  No standard student accounts registered under database registers.
                </div>
              ) : (
                <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="bg-[#1e252b] text-white border-b border-slate-800 text-[10px] uppercase font-mono font-bold tracking-wider">
                          <th className="p-4">Candidate Subscriber Reference</th>
                          <th className="p-4">Email Address Reference</th>
                          <th className="p-4">Enrolled Timestamp</th>
                          <th className="p-4 text-right">Catalog Control Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-150 text-sm font-sans text-slate-700">
                        {members.map((m) => (
                          <tr key={m.id} className="hover:bg-slate-50">
                            <td className="p-4 font-bold text-slate-900">{m.name}</td>
                            <td className="p-4 font-mono text-xs text-slate-600">{m.email}</td>
                            <td className="p-4 font-mono text-xs text-slate-550">
                              {new Date(m.createdAt).toLocaleString()}
                            </td>
                            <td className="p-3 text-right">
                              <button
                                onClick={() => handleDeleteMember(m.id)}
                                className="px-3.5 py-1.5 bg-red-50 hover:bg-red-100 border border-red-100 text-red-650 font-bold text-xs uppercase tracking-wider rounded-lg transition-colors cursor-pointer inline-flex items-center gap-1"
                              >
                                <Trash2 className="h-3.5 w-3.5" /> Purge Profile
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

            </motion.div>
          )}

          {/* ========================================================== */}
          {/* STUDENT ENQUIRIES / RESPONSE AGENTS (ADMIN PORTAL) */}
          {/* ========================================================== */}
          {activeTab === "enquiries" && user.role === "admin" && (
            <motion.div
              key="enquiries_view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div>
                <h2 className="text-2xl font-extrabold tracking-tight text-slate-900">Student Enquiries Archives</h2>
                <p className="text-xs text-slate-500 mt-1">Review inquiries submitted via student email gates. Maintain automated replies dispatch loop.</p>
              </div>

              {loadingQueries ? (
                <div className="py-20 text-center font-mono text-xs text-slate-400">
                  Accessing general mail accounts...
                </div>
              ) : queries.length === 0 ? (
                <div className="py-16 text-center text-slate-400 font-mono text-sm border bg-white rounded-2xl">
                  No candidate email queries received in archives.
                </div>
              ) : (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  
                  {/* Inquiry log listing */}
                  <div className="lg:col-span-7 space-y-4">
                    {queries.map((q) => (
                      <div 
                        key={q.id} 
                        className={`bg-white border rounded-2xl p-5 shadow-sm space-y-4 transition-all cursor-pointer ${
                          respondingQueryId === q.id ? "border-[#fab005] ring-2 ring-[#fab005]/20 bg-[#fffbeb]/20" : "border-slate-200"
                        }`}
                        onClick={() => {
                          setRespondingQueryId(q.id);
                          setAdminResponseText(q.response || "");
                        }}
                      >
                        <div className="flex items-center justify-between gap-1">
                          <div>
                            <span className="text-xs font-sans font-bold text-slate-900 block">{q.subject}</span>
                            <span className="text-[10px] text-slate-500 mt-0.5 block font-mono">
                              From: {q.name} ({q.email})
                            </span>
                          </div>
                          <div>
                            {q.status === "replied" ? (
                              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 text-[9px] font-mono font-bold uppercase tracking-wider border border-emerald-150 rounded-lg">
                                Replied
                              </span>
                            ) : (
                              <span className="px-2 py-0.5 bg-red-50 text-red-700 text-[9px] font-mono font-bold uppercase tracking-wider border border-red-150 rounded-lg animate-pulse">
                                Unread Attention
                              </span>
                            )}
                          </div>
                        </div>

                        <p className="text-xs text-slate-700 bg-neutral-50 p-3 rounded-lg font-mono leading-relaxed">
                          {q.message}
                        </p>

                        {q.response && (
                          <div className="p-3.5 bg-slate-50 border-l-[3px] border-[#fab005] rounded-r-xl space-y-1 text-xs">
                            <div className="flex items-center gap-1 text-[9px] uppercase font-mono tracking-wider font-bold text-slate-500">
                              <span>Outgoing Response Archives</span>
                            </div>
                            <p className="text-slate-800 leading-relaxed italic">{q.response}</p>
                          </div>
                        )}

                        <div className="flex items-center justify-between border-t border-slate-100/80 pt-3">
                          <span className="text-[9px] text-slate-400 font-mono block">
                            Arrived: {new Date(q.createdAt).toLocaleString()}
                          </span>
                          <div className="space-x-2" onClick={(e) => e.stopPropagation()}>
                            <button
                              onClick={() => {
                                setRespondingQueryId(q.id);
                                setAdminResponseText(q.response || "");
                              }}
                              className="text-xs text-[#b58000] font-sans font-semibold hover:underline"
                            >
                              Reply
                            </button>
                            <span className="text-slate-350">•</span>
                            <button
                              onClick={() => handleDeleteQuery(q.id)}
                              className="text-xs text-red-500 hover:underline"
                            >
                              Purge
                            </button>
                          </div>
                        </div>

                      </div>
                    ))}
                  </div>

                  {/* Responding active panel */}
                  <div className="lg:col-span-5">
                    <AnimatePresence mode="wait">
                      {respondingQueryId ? (
                        <motion.div 
                          initial={{ opacity: 0, scale: 0.98 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.98 }}
                          className="bg-white border-2 border-[#fab005]/40 p-6 rounded-2xl shadow-sm space-y-4 sticky top-24"
                        >
                          <div>
                            <span className="text-xs font-mono font-bold uppercase tracking-wider text-[#fab005] block">Compose Mail Response</span>
                            <h3 className="font-sans font-extrabold text-slate-900 text-sm mt-0.5">
                              Enquiry ID: {respondingQueryId}
                            </h3>
                          </div>

                          <form onSubmit={handleRespondQuery} className="space-y-4">
                            <div className="space-y-1">
                              <label className="text-[9px] font-mono uppercase tracking-wider text-slate-400 font-bold">Mail Body Response</label>
                              <textarea
                                required
                                rows={6}
                                value={adminResponseText}
                                onChange={(e) => setAdminResponseText(e.target.value)}
                                placeholder="Type the digital mail solution envelop to dispatch..."
                                className="w-full bg-[#fafafa] border border-slate-250 rounded-xl p-3.5 text-sm focus:outline-none focus:border-[#fab005] transition-colors leading-relaxed"
                              />
                            </div>

                            <div className="flex gap-2 justify-end">
                              <button
                                type="button"
                                onClick={() => setRespondingQueryId(null)}
                                className="px-3.5 py-2 bg-slate-105 border border-slate-250 text-slate-650 rounded-xl text-xs font-semibold cursor-pointer"
                              >
                                Abort
                              </button>
                              <button
                                type="submit"
                                className="px-5 py-2 bg-[#fab005] hover:bg-amber-400 text-slate-950 rounded-xl text-xs font-bold uppercase tracking-wider cursor-pointer"
                              >
                                Send Response Mail
                              </button>
                            </div>
                          </form>
                        </motion.div>
                      ) : (
                        <div className="p-8 text-center text-slate-400 border border-dashed border-slate-200 bg-white rounded-2xl text-xs font-mono sticky top-24">
                          Select an enquiry card on the left to activate drafting envelop.
                        </div>
                      )}
                    </AnimatePresence>
                  </div>

                </div>
              )}

            </motion.div>
          )}

          {/* ========================================================== */}
          {/* PERSONAL USER PROFILE PARAMETERS SECTION */}
          {/* ========================================================== */}
          {activeTab === "profile" && (
            <motion.div
              key="profile_view"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 md:grid-cols-12 gap-8"
            >
              
              {/* Profile details */}
              <div className="md:col-span-6 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
                <div>
                  <h3 className="font-sans font-extrabold text-slate-900 text-lg">Modify Personal Particulars</h3>
                  <p className="text-xs text-slate-500 mt-1">Manage standard contact name and registered library emails.</p>
                </div>

                {profileFeedback && (
                  <div className={`p-3.5 rounded-xl text-xs ${profileFeedback.type === "error" ? "bg-red-50 text-red-650 border border-red-150" : "bg-emerald-50 text-emerald-705 border border-emerald-150"}`}>
                    {profileFeedback.msg}
                  </div>
                )}

                <form onSubmit={handleUpdateProfile} className="space-y-4">
                  
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">User Identity Display Name</label>
                    <input
                      type="text"
                      required
                      value={profileName}
                      onChange={(e) => setProfileName(e.target.value)}
                      className="w-full bg-[#fafafa] border border-slate-250 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#fab005] transition-colors"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Library Email Address</label>
                    <input
                      type="email"
                      required
                      value={profileEmail}
                      onChange={(e) => setProfileEmail(e.target.value)}
                      className="w-full bg-[#fafafa] border border-slate-250 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#fab005] transition-colors font-mono text-xs text-slate-500"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submittingProfile}
                    className="w-full py-2.5 bg-slate-900 hover:bg-slate-850 text-[#fab005] font-sans font-bold text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer disabled:opacity-50"
                  >
                    {submittingProfile ? "Updating Particulars..." : "Save Record Particulars"}
                  </button>

                </form>
              </div>

              {/* Password update details */}
              <div className="md:col-span-6 bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
                <div>
                  <h3 className="font-sans font-extrabold text-slate-900 text-lg">Change Security Password</h3>
                  <p className="text-xs text-slate-500 mt-1">Upgrade vault passcode keys periodically to ensure encryption margins.</p>
                </div>

                {passwordFeedback && (
                  <div className={`p-3.5 rounded-xl text-xs ${passwordFeedback.type === "error" ? "bg-red-50 text-red-650 border border-red-150" : "bg-emerald-50 text-emerald-705 border border-emerald-150"}`}>
                    {passwordFeedback.msg}
                  </div>
                )}

                <form onSubmit={handleChangePassword} className="space-y-4">
                  
                  <div className="space-y-1">
                    <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Current verifying Password</label>
                    <input
                      type="password"
                      required
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                      placeholder="••••••"
                      className="w-full bg-[#fafafa] border border-slate-250 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#fab005] transition-colors font-mono"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">New secure Password</label>
                    <input
                      type="password"
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="Minimum 6 characters"
                      className="w-full bg-[#fafafa] border border-slate-250 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#fab005] transition-colors font-mono"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold block">Confirm new Password</label>
                    <input
                      type="password"
                      required
                      value={confirmNewPassword}
                      onChange={(e) => setConfirmNewPassword(e.target.value)}
                      placeholder="••••••"
                      className="w-full bg-[#fafafa] border border-slate-250 rounded-xl px-3.5 py-2.5 text-sm focus:outline-none focus:border-[#fab005] transition-colors font-mono"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submittingPassword}
                    className="w-full py-2.5 bg-slate-900 hover:bg-slate-850 text-[#fab005] font-sans font-bold text-xs uppercase tracking-wider rounded-xl transition-colors cursor-pointer disabled:opacity-50"
                  >
                    {submittingPassword ? "Upgrading security..." : "Confirm Passcode Change"}
                  </button>

                </form>
              </div>

            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* FOOTER SYSTEM DESIGN */}
      <footer className="bg-white border-t border-slate-200 mt-12 py-6 text-center text-xs font-mono text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <span>Digital Library digitization Match Portal • Task 5 Automated solution</span>
          <span className="text-[10px]">Oasis Infobyte Program Series Client • Secure persistent memory index</span>
        </div>
      </footer>

    </div>
  );
}

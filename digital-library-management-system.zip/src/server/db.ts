import fs from "fs/promises";
import path from "path";
import crypto from "crypto";

// Server-side internal Types
export interface User {
  id: string;
  email: string;
  name: string;
  passwordHash: string;
  salt: string;
  role: "admin" | "user";
  createdAt: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  category: string;
  isbn: string;
  totalCopies: number;
  availableCopies: number;
  location: string;
  finePerDay: number;
  synopsis: string;
  publishedYear: number;
}

export interface Transaction {
  id: string;
  userId: string;
  userName: string;
  bookId: string;
  bookTitle: string;
  issueDate: string; // ISO String
  dueDate: string; // ISO String
  returnDate: string | null; // ISO String or null
  status: "borrowed" | "returned" | "reserved";
  fineAmount: number;
  finePaid: boolean;
  isAdvanceBooking: boolean;
}

export interface ContactQuery {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: "unread" | "read" | "replied";
  response?: string;
  createdAt: string;
}

interface DatabaseSchema {
  users: User[];
  books: Book[];
  transactions: Transaction[];
  queries: ContactQuery[];
}

const DB_FILE_PATH = path.join(process.cwd(), "data", "library_db.json");

// Helper to secure password hashing
function hashPassword(password: string, salt: string): string {
  return crypto.pbkdf2Sync(password, salt, 1000, 64, "sha512").toString("hex");
}

function generateSalt(): string {
  return crypto.randomBytes(16).toString("hex");
}

export class LibraryDatabase {
  private static initialized = false;

  private static getInitData(): DatabaseSchema {
    const saltAdmin = generateSalt();
    const saltStudent = generateSalt();

    const mockAdmin: User = {
      id: "usr_admin",
      email: "admin@example.com",
      name: "Chief Librarian Admin",
      passwordHash: hashPassword("admin123", saltAdmin),
      salt: saltAdmin,
      role: "admin",
      createdAt: new Date().toISOString()
    };

    const mockStudent: User = {
      id: "usr_student",
      email: "student@example.com",
      name: "Alex Devishankar",
      passwordHash: hashPassword("123456", saltStudent),
      salt: saltStudent,
      role: "user",
      createdAt: new Date().toISOString()
    };

    const defaultBooks: Book[] = [
      {
        id: "book_1",
        title: "Introduction to Java Programming and Data Structures",
        author: "Y. Daniel Liang",
        category: "Java Development",
        isbn: "978-0134670942",
        totalCopies: 4,
        availableCopies: 4,
        location: "Shelf A-3",
        finePerDay: 0.50,
        synopsis: "A comprehensive guide on learning core fundamental programming logic structures with Java's modular system paradigms.",
        publishedYear: 2018
      },
      {
        id: "book_2",
        title: "Effective Java (3rd Edition)",
        author: "Joshua Bloch",
        category: "Java Development",
        isbn: "978-0134685991",
        totalCopies: 3,
        availableCopies: 2, // 1 already issued pre-seeded
        location: "Shelf A-4",
        finePerDay: 0.75,
        synopsis: "Best-practice guidelines for writing elegant, robust, and clean Java code, compiled by one of the primary language designers.",
        publishedYear: 2017
      },
      {
        id: "book_3",
        title: "Database System Concepts (7th Edition)",
        author: "Abraham Silberschatz",
        category: "Database Systems",
        isbn: "978-0073523323",
        totalCopies: 2,
        availableCopies: 2,
        location: "Shelf B-2",
        finePerDay: 1.00,
        synopsis: "The class-leading textbook offering foundational concepts of database design, transactions, recovery, indexing, and SQLCTE systems.",
        publishedYear: 2019
      },
      {
        id: "book_4",
        title: "Full-Stack Web Engineering with React, Node & Express",
        author: "Robin Wieruch",
        category: "Web Development",
        isbn: "978-1735626011",
        totalCopies: 2,
        availableCopies: 1, // 1 borrowed
        location: "Shelf C-1",
        finePerDay: 0.50,
        synopsis: "A road to building modern SPAs and full-stack servers using JavaScript / TypeScript with React components, routing, and databases.",
        publishedYear: 2021
      },
      {
        id: "book_5",
        title: "Java: The Complete Reference (12th Edition)",
        author: "Herbert Schildt",
        category: "Java Development",
        isbn: "978-1260440232",
        totalCopies: 1,
        availableCopies: 0, // 0 available - perfect for showing Advance booking / Reservation functionality!
        location: "Shelf A-5",
        finePerDay: 1.50,
        synopsis: "The definitive guide to the entire Java ecosystem, including API, class libraries, inheritance models, and lambda streams.",
        publishedYear: 2021
      },
      {
        id: "book_6",
        title: "Cracking the Coding Interview",
        author: "Gayle Laakmann McDowell",
        category: "General Aptitude",
        isbn: "978-0984782857",
        totalCopies: 5,
        availableCopies: 5,
        location: "Shelf D-3",
        finePerDay: 0.50,
        synopsis: "189 programming questions and solutions ranging from basic binary search tree nodes to advanced system design criteria.",
        publishedYear: 2015
      }
    ];

    const todayStr = new Date().toISOString();
    // Pre-seeded transitions to demonstrate past audits
    const defaultTransactions: Transaction[] = [
      {
        id: "tx_1",
        userId: "usr_student",
        userName: "Alex Devishankar",
        bookId: "book_2",
        bookTitle: "Effective Java (3rd Edition)",
        issueDate: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString(), // 10 days ago
        dueDate: new Date(Date.now() + 4 * 24 * 60 * 60 * 1000).toISOString(), // due in 4 days
        returnDate: null,
        status: "borrowed",
        fineAmount: 0.0,
        finePaid: false,
        isAdvanceBooking: false
      },
      {
        id: "tx_2",
        userId: "usr_student",
        userName: "Alex Devishankar",
        bookId: "book_4",
        bookTitle: "Full-Stack Web Engineering with React, Node & Express",
        issueDate: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000).toISOString(), // 20 days ago
        dueDate: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(), // overdue by 6 days!
        returnDate: null,
        status: "borrowed",
        fineAmount: 3.0, // 6 days * $0.50
        finePaid: false,
        isAdvanceBooking: false
      },
      {
        id: "tx_3",
        userId: "usr_student",
        userName: "Alex Devishankar",
        bookId: "book_1",
        bookTitle: "Introduction to Java Programming and Data Structures",
        issueDate: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
        dueDate: new Date(Date.now() - 16 * 24 * 60 * 60 * 1000).toISOString(),
        returnDate: new Date(Date.now() - 16 * 24 * 60 * 60 * 1000).toISOString(), // returned on due date
        status: "returned",
        fineAmount: 0,
        finePaid: true,
        isAdvanceBooking: false
      }
    ];

    const defaultQueries: ContactQuery[] = [
      {
        id: "qry_1",
        name: "Alex Devishankar",
        email: "student@example.com",
        subject: "Suggesting Spring Boot Microservices Book",
        message: "Hello librarian, could we please add 'Spring Boot in Action' by Craig Walls to our computer science collection? I need this for my final project. Thank you!",
        status: "replied",
        response: "Great suggestion! We have ordered 2 copies under the 'Java Development' category. They should arrive in Shelf A-6 next Tuesday.",
        createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
      },
      {
        id: "qry_2",
        name: "Suresh Gupta",
        email: "suresh@example.com",
        subject: "Digital Fine Payment Option inquiry",
        message: "Is there a way to pay the fine through credit card or UPI directly inside this digital portal?",
        status: "unread",
        createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
      }
    ];

    return {
      users: [mockAdmin, mockStudent],
      books: defaultBooks,
      transactions: defaultTransactions,
      queries: defaultQueries
    };
  }

  static async init(): Promise<void> {
    if (this.initialized) return;
    try {
      const dir = path.dirname(DB_FILE_PATH);
      await fs.mkdir(dir, { recursive: true });
      try {
        await fs.access(DB_FILE_PATH);
      } catch {
        const initialSchema = this.getInitData();
        await fs.writeFile(DB_FILE_PATH, JSON.stringify(initialSchema, null, 2), "utf8");
      }
      this.initialized = true;
    } catch (e) {
      console.error("Failed to initialize database file:", e);
    }
  }

  static async readData(): Promise<DatabaseSchema> {
    await this.init();
    try {
      const content = await fs.readFile(DB_FILE_PATH, "utf8");
      return JSON.parse(content) as DatabaseSchema;
    } catch {
      return this.getInitData();
    }
  }

  static async writeData(data: DatabaseSchema): Promise<void> {
    await this.init();
    await fs.writeFile(DB_FILE_PATH, JSON.stringify(data, null, 2), "utf8");
  }

  // --- Users Modules ---
  static async createUser(name: string, email: string, passwordPlain: string, role: "admin" | "user" = "user"): Promise<User> {
    const data = await this.readData();
    const lowerEmail = email.trim().toLowerCase();
    
    if (data.users.find(u => u.email.toLowerCase() === lowerEmail)) {
      throw new Error("An account with this email address already exists.");
    }

    const salt = generateSalt();
    const newUser: User = {
      id: "usr_" + crypto.randomBytes(8).toString("hex"),
      email: lowerEmail,
      name: name.trim(),
      passwordHash: hashPassword(passwordPlain, salt),
      salt,
      role,
      createdAt: new Date().toISOString()
    };

    data.users.push(newUser);
    await this.writeData(data);
    return newUser;
  }

  static async authenticateUser(email: string, passwordPlain: string): Promise<User> {
    const data = await this.readData();
    const lowerEmail = email.trim().toLowerCase();
    const user = data.users.find(u => u.email.toLowerCase() === lowerEmail);
    if (!user) {
      throw new Error("Invalid login email or password credentials.");
    }

    const testHash = hashPassword(passwordPlain, user.salt);
    if (testHash !== user.passwordHash) {
      throw new Error("Invalid password credentials.");
    }

    return user;
  }

  static async getAllMembers(): Promise<User[]> {
    const data = await this.readData();
    return data.users.filter(u => u.role === "user");
  }

  static async deleteMember(id: string): Promise<void> {
    const data = await this.readData();
    data.users = data.users.filter(u => u.id !== id);
    await this.writeData(data);
  }

  static async updateProfile(userId: string, name: string, email: string): Promise<User> {
    const data = await this.readData();
    const userIndex = data.users.findIndex(u => u.id === userId);
    if (userIndex === -1) {
      throw new Error("User profile has expired.");
    }

    const lowerEmail = email.trim().toLowerCase();
    const emailConflict = data.users.find(u => u.email.toLowerCase() === lowerEmail && u.id !== userId);
    if (emailConflict) {
      throw new Error("The email is already used by another member.");
    }

    data.users[userIndex].name = name.trim();
    data.users[userIndex].email = lowerEmail;

    await this.writeData(data);
    return data.users[userIndex];
  }

  static async changePassword(userId: string, currentPasswordPlain: string, newPasswordPlain: string): Promise<void> {
    const data = await this.readData();
    const userIndex = data.users.findIndex(u => u.id === userId);
    if (userIndex === -1) {
      throw new Error("Authentication verification expired.");
    }

    const user = data.users[userIndex];
    const testHash = hashPassword(currentPasswordPlain, user.salt);
    if (testHash !== user.passwordHash) {
      throw new Error("The current password verification failed.");
    }

    const newSalt = generateSalt();
    data.users[userIndex].salt = newSalt;
    data.users[userIndex].passwordHash = hashPassword(newPasswordPlain, newSalt);

    await this.writeData(data);
  }

  // --- Core Bookkeeping Modules (CRUD) ---
  static async getBooks(): Promise<Book[]> {
    const data = await this.readData();
    return data.books;
  }

  static async getBookById(id: string): Promise<Book | null> {
    const data = await this.readData();
    return data.books.find(b => b.id === id) || null;
  }

  static async createBook(bookData: Omit<Book, "id" | "availableCopies">): Promise<Book> {
    const data = await this.readData();
    const newBook: Book = {
      ...bookData,
      id: "book_" + crypto.randomBytes(8).toString("hex"),
      availableCopies: bookData.totalCopies
    };
    data.books.push(newBook);
    await this.writeData(data);
    return newBook;
  }

  static async updateBook(id: string, updatedFields: Partial<Book>): Promise<Book> {
    const data = await this.readData();
    const index = data.books.findIndex(b => b.id === id);
    if (index === -1) {
      throw new Error("Requested book not found.");
    }

    const original = data.books[index];
    // recalculate available copies. In a robust system:
    // available = total - (all borrowed transactions of this book)
    const activeBorrows = data.transactions.filter(t => t.bookId === id && t.status === "borrowed").length;
    let newTotal = updatedFields.totalCopies !== undefined ? updatedFields.totalCopies : original.totalCopies;
    let newAvailable = Math.max(0, newTotal - activeBorrows);

    data.books[index] = {
      ...original,
      ...updatedFields,
      availableCopies: newAvailable
    };

    await this.writeData(data);
    return data.books[index];
  }

  static async deleteBook(id: string): Promise<void> {
    const data = await this.readData();
    // Guard: Prevent delete if there are active loans
    const hasActiveLoans = data.transactions.some(t => t.bookId === id && t.status === "borrowed");
    if (hasActiveLoans) {
      throw new Error("This book cannot be deleted because copies are currently issued to library members.");
    }

    data.books = data.books.filter(b => b.id !== id);
    // clean up reservations
    data.transactions = data.transactions.filter(t => t.bookId !== id);
    await this.writeData(data);
  }

  // --- Circulation and Transactions Processing ---
  static async getTransactions(userId?: string): Promise<Transaction[]> {
    const data = await this.readData();
    // Trigger dynamic fine calculations before returning
    let updated = false;
    const now = new Date();

    data.transactions.forEach(t => {
      if (t.status === "borrowed" && !t.returnDate) {
        const dueDateObj = new Date(t.dueDate);
        if (now > dueDateObj) {
          const diffMs = now.getTime() - dueDateObj.getTime();
          const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));
          // Let's lookup finePerDay from book
          const book = data.books.find(b => b.id === t.bookId);
          const rate = book ? book.finePerDay : 0.50;
          const calculatedFine = Number((diffDays * rate).toFixed(2));
          if (t.fineAmount !== calculatedFine) {
            t.fineAmount = calculatedFine;
            updated = true;
          }
        }
      }
    });

    if (updated) {
      await this.writeData(data);
    }

    if (userId) {
      return data.transactions.filter(t => t.userId === userId).sort((a, b) => b.issueDate.localeCompare(a.issueDate));
    }
    return data.transactions.sort((a, b) => b.issueDate.localeCompare(a.issueDate));
  }

  // Issue / Borrow a Book
  static async issueBook(userId: string, userName: string, bookId: string): Promise<Transaction> {
    const data = await this.readData();
    const book = data.books.find(b => b.id === bookId);
    if (!book) throw new Error("Requested book not found.");

    // Limit check: check if user already has this book borrowed
    const alreadyBorrowed = data.transactions.some(t => t.userId === userId && t.bookId === bookId && t.status === "borrowed");
    if (alreadyBorrowed) {
      throw new Error("You already have an active loan on a copy of this book.");
    }

    // Limit check: max 5 active loans
    const activeLoans = data.transactions.filter(t => t.userId === userId && t.status === "borrowed").length;
    if (activeLoans >= 5) {
      throw new Error("Issue limit exceeded. You have reached the maximum allowed limit of 5 simultaneous borrowed books.");
    }

    if (book.availableCopies <= 0) {
      throw new Error("No copies currently available for immediate lending. Please use 'Advance Booking / Reservation' instead.");
    }

    // Process issue
    book.availableCopies -= 1;
    
    const issueDate = new Date();
    const dueDate = new Date();
    dueDate.setDate(dueDate.getDate() + 14); // 14-day standard borrow limit

    const transaction: Transaction = {
      id: "tx_" + crypto.randomBytes(8).toString("hex"),
      userId,
      userName,
      bookId,
      bookTitle: book.title,
      issueDate: issueDate.toISOString(),
      dueDate: dueDate.toISOString(),
      returnDate: null,
      status: "borrowed",
      fineAmount: 0.0,
      finePaid: false,
      isAdvanceBooking: false
    };

    data.transactions.push(transaction);
    await this.writeData(data);
    return transaction;
  }

  // Return a Book
  static async returnBook(transactionId: string): Promise<Transaction> {
    const data = await this.readData();
    const tx = data.transactions.find(t => t.id === transactionId);
    if (!tx) throw new Error("Loan transaction details not found.");
    if (tx.status === "returned") throw new Error("This book has already been returned.");

    const book = data.books.find(b => b.id === tx.bookId);
    
    // Process return
    tx.returnDate = new Date().toISOString();
    tx.status = "returned";
    
    if (tx.fineAmount > 0) {
      // Outstanding fine is preserved; user must pay fine to trigger finePaid: true
    } else {
      tx.finePaid = true;
    }

    // If it was parsed as borrowed, check back into pool, or hand to first available reservation
    if (book) {
      // Find if anyone else reserved this book
      const firstReservation = data.transactions.find(t => t.bookId === book.id && t.status === "reserved");
      if (firstReservation) {
        // Change status from reserved to borrowed directly for the reserved member!
        firstReservation.status = "borrowed";
        firstReservation.issueDate = new Date().toISOString();
        
        const nextDue = new Date();
        nextDue.setDate(nextDue.getDate() + 14);
        firstReservation.dueDate = nextDue.toISOString();
        // available copies remains 0 because it went directly to the reserving member!
      } else {
        book.availableCopies = Math.min(book.totalCopies, book.availableCopies + 1);
      }
    }

    await this.writeData(data);
    return tx;
  }

  // Advance Booking / Reservation
  static async reserveBook(userId: string, userName: string, bookId: string): Promise<Transaction> {
    const data = await this.readData();
    const book = data.books.find(b => b.id === bookId);
    if (!book) throw new Error("Book details not found.");

    // Guard: only reserve if copies are currently 0
    if (book.availableCopies > 0) {
      throw new Error("Copies are available immediately in stock. Please select 'Issue Book' instead.");
    }

    // Guard: already active loan or reservation
    const activeEntry = data.transactions.some(t => t.userId === userId && t.bookId === bookId && (t.status === "borrowed" || t.status === "reserved"));
    if (activeEntry) {
      throw new Error("You already have an active reservation or loan transaction registered for this title.");
    }

    const transaction: Transaction = {
      id: "tx_" + crypto.randomBytes(8).toString("hex"),
      userId,
      userName,
      bookId,
      bookTitle: book.title,
      issueDate: new Date().toISOString(), // Reservation registered date
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(), // reserve hold limit is 7 days
      returnDate: null,
      status: "reserved",
      fineAmount: 0.0,
      finePaid: false,
      isAdvanceBooking: true
    };

    data.transactions.push(transaction);
    await this.writeData(data);
    return transaction;
  }

  // Pay Fine Simulation
  static async payFine(transactionId: string): Promise<Transaction> {
    const data = await this.readData();
    const tx = data.transactions.find(t => t.id === transactionId);
    if (!tx) throw new Error("Transaction not found.");

    tx.finePaid = true;
    tx.fineAmount = 0.0;
    
    await this.writeData(data);
    return tx;
  }

  // Cancel reservation
  static async cancelReservation(transactionId: string): Promise<void> {
    const data = await this.readData();
    data.transactions = data.transactions.filter(t => t.id !== transactionId);
    await this.writeData(data);
  }

  // --- User Queries / simulated email communication ---
  static async getQueries(): Promise<ContactQuery[]> {
    const data = await this.readData();
    return data.queries.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  static async submitQuery(name: string, email: string, subject: string, message: string): Promise<ContactQuery> {
    const data = await this.readData();
    const newQuery: ContactQuery = {
      id: "qry_" + crypto.randomBytes(8).toString("hex"),
      name: name.trim(),
      email: email.trim().toLowerCase(),
      subject: subject.trim(),
      message: message.trim(),
      status: "unread",
      createdAt: new Date().toISOString()
    };
    data.queries.push(newQuery);
    await this.writeData(data);
    return newQuery;
  }

  static async respondToQuery(id: string, responseText: string): Promise<ContactQuery> {
    const data = await this.readData();
    const qIndex = data.queries.findIndex(q => q.id === id);
    if (qIndex === -1) {
      throw new Error("Reference query not found.");
    }

    data.queries[qIndex].status = "replied";
    data.queries[qIndex].response = responseText.trim();
    
    await this.writeData(data);
    return data.queries[qIndex];
  }

  static async deleteQuery(id: string): Promise<void> {
    const data = await this.readData();
    data.queries = data.queries.filter(q => q.id !== id);
    await this.writeData(data);
  }

  static async getDashboardStats(): Promise<any> {
    const data = await this.readData();
    const stats = {
      totalBooks: data.books.reduce((acc, b) => acc + b.totalCopies, 0),
      uniqueTitles: data.books.length,
      activeBorrows: data.transactions.filter(t => t.status === "borrowed").length,
      pendingReservations: data.transactions.filter(t => t.status === "reserved").length,
      unpaidFines: Number(data.transactions
        .filter(t => t.status === "borrowed" && t.fineAmount > 0 && !t.finePaid)
        .reduce((sum, t) => sum + t.fineAmount, 0)
        .toFixed(2)),
      totalMembers: data.users.filter(u => u.role === "user").length
    };
    return stats;
  }
}

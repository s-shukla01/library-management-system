export interface User {
  id: string;
  name: string;
  email: string;
  role: "admin" | "user";
  createdAt: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  category: string;
  isbn: string;
  totalCopies: number;
  availableCopies: number;
  location: string;
  finePerDay: number;
  synopsis: string;
  publishedYear: number;
}

export interface Transaction {
  id: string;
  userId: string;
  userName: string;
  bookId: string;
  bookTitle: string;
  issueDate: string; // ISO String
  dueDate: string; // ISO String
  returnDate: string | null; // ISO String or null
  status: "borrowed" | "returned" | "reserved";
  fineAmount: number;
  finePaid: boolean;
  isAdvanceBooking: boolean;
}

export interface ContactQuery {
  id: string;
  name: string;
  email: string;
  subject: string;
  message: string;
  status: "unread" | "read" | "replied";
  response?: string;
  createdAt: string;
}

export interface DashboardStats {
  totalBooks: number;
  uniqueTitles: number;
  activeBorrows: number;
  pendingReservations: number;
  unpaidFines: number;
  totalMembers: number;
}
